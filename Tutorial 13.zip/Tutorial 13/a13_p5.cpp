//CH-230-B
//a13_p.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream> 
using namespace std; 
  
class A 
{ 
  int x; 
public: 
  A() {}
  //default cnstructor
  A(int i) { x = i; } 
  void print() { cout << x; } 
}; 
  
class B: virtual public A 
{ 
public: 
  B():A(10) {  } 
}; 
  
class C:  virtual public A  
{ 
public: 
  C():A(10) {  } 
}; 
  
class D: public B, public C { 
}; 
  
int main() 
{ 
    D d; 
    d.print(); 
    return 0; 
} 

// Erros-
// a13_p5.cpp: In function 'int main()':
// a13_p5.cpp:30:7: error: use of deleted function 'D::D()'
//      D d;
//        ^
// a13_p5.cpp:25:7: note: 'D::D()' is implicitly deleted because the default definition would be ill-formed:
//  class D: public B, public C {
//        ^
// a13_p5.cpp:25:7: error: no matching function for call to 'A::A()'
// a13_p5.cpp:9:3: note: candidate: A::A(int)
//    A(int i) { x = i; }
//    ^
// a13_p5.cpp:9:3: note:   candidate expects 1 argument, 0 provided
// a13_p5.cpp:4:7: note: candidate: constexpr A::A(const A&)
//  class A
//        ^
// a13_p5.cpp:4:7: note:   candidate expects 1 argument, 0 provided
// a13_p5.cpp:4:7: note: candidate: constexpr A::A(A&&)
// a13_p5.cpp:4:7: note:   candidate expects 1 argument, 0 provided

// Reason for the errors-
// Because the class D is being inherited from the Class B and Class C
// which are further inherited from Class A, the creation of D d, requires 
// default constructor from Class A, which has not been provide.
// If we make a default constructor in Class A, it will solve the compilation
// errors.