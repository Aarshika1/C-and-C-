//CH-230-B
//a13_p6.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<fstream>
#include "Matrix.h"
#include "Vector.h"
using namespace std;

int main()
{
     Matrix a;
    Vector b;

    ifstream infile1, infile2;
    ofstream outfile1, outfile2;

    //First input file
    infile1.open("in1.txt", ios::in);
    if (!infile1)
    {
        cerr << "Failure..." << endl;
        exit(1);
    }
    infile1 >> a;
    cout << "Matrix: \n";
    cout << a;
    cout << endl;
    infile1.close();

    //The second input file
    infile2.open("in2.txt", ios::in);
    if (!infile2)
    {
        cerr << "Failure..." << endl;
        exit(1);
    }

    infile2 >> b;
    cout << "Vector: ";
    cout << b;

    cout << endl;
    infile2.close();

    //Opening the outputfile one
    outfile1.open("out1.txt", ios::out);
    if (!outfile1)
    {
        cerr << "Failure" << endl;
        exit(1);
    }

    //Printing in the console screen
    cout << "Multiplication: ";
    cout << (a * b);

    //Writting in the file
    outfile1 << "Multiplication: ";
    outfile1 << (a * b)<<endl;
    outfile1.close();


    return 0;

}
