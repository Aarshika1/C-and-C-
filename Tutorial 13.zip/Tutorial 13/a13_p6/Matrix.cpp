//CH-230-B
//a13_p6.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include "Matrix.h"
#include <fstream>
#include<stdlib.h>

Matrix::Matrix()
{

}

Matrix::Matrix(int r,int c)
{
    row = r;
    column = c;
    matrix = (int**)malloc(sizeof(int*)*row);
    {
        for(int i=0;i<row;i++)
        {
            matrix[i] = (int*)malloc(sizeof(int)*column);
        }
    }
}


Matrix::~Matrix()
{
    std::cout<<"Destroying Matrix..."<<std::endl;;
    delete[] matrix;
}

Vector Matrix::operator*(const Vector &v)
{
    if (this->column == v.getsize())
    {

        Vector out(this->row);

        for (int i = 0; i < this->row; i++)
        {
            int val = 0;
            for (int j = 0; j < this->column; j++)
            {
                val = val + this->matrix[i][j] * v.getptr()[j]; //
            }
            out.set(i, val);
        }

        return out;
    }
    else
    {
        cout << "Incompatible...";
    }
    return v;
    
}
Matrix Matrix::operator+(const Vector &v)
{

        Matrix m(this->row,this->column);

        for (int i = 0; i < this->row; i++)
        {
            int val = 0;
            for (int j = 0; j < this->column; j++)
            {
                val = val + this->matrix[i][j] + v.getptr()[j];
                m.set(i,j, val);
            }
        }

        return m;
    
}
std::ostream& operator << (std::ostream& os,const Matrix& m)
{
	for(int i=0;i<m.row;i++)
    {
        for(int j=0;j<m.column;j++)
        {
            os<<m.matrix[i][j]<<" ";
        }
        std::cout<<"\n";
    }
	return os;
}
//Overloading the << operator

std::istream& operator >> (std::istream& is, Matrix& m)
{
	is>>m.row>>m.column;
    m.matrix = (int**)malloc(sizeof(int*)*m.row);
    {
        for(int i=0;i<m.row;i++)
        {
            m.matrix[i] = (int*)malloc(sizeof(int)*m.column);
        }
    }
    for(int i=0;i<m.row;i++)
    {
        for(int j=0;j<m.column;j++)
        {
            is>>m.matrix[i][j];
        }
    }
	return is;
}

void Matrix::set(int r,int c,int value)
{
    matrix[r][c]=value;
}
