//CH-230-B
//a13_p6.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#ifndef MATRIX_H_INCLUDED
#define MATRIX_H_INCLUDED
#include<iostream>
#include "Vector.h"
class Matrix
{
    public:
    int row,column,**matrix;
    public:
    Matrix();
    Matrix(int,int);
    ~Matrix();
    //constructors
    void set(int,int,int);
    Matrix operator+(const Vector &);
    Vector operator*(const Vector &);
    friend std::ostream& operator<<(std::ostream& os,const Matrix& m);
	friend std::istream& operator>>(std::istream& is, Matrix& m);

};



#endif // MATRIX_H_INCLUDED
