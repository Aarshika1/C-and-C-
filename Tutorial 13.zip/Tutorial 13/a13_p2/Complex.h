//CH-230-B
//a13_p2.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#ifndef COMPLEX_H_INCLUDED
#define COMPLEX_H_INCLUDED
#include<iostream>
using namespace std;
class Complex
{
    private:
    float real;
    float imaginary;
    //Declaring properties
    public:
    void setcomplex(float re, float img);
    //Setter for the complex
    float getreal();
    float getimaginary();
    //getter for the real and imaginary part
    void printComplex();
    Complex();
    //Empty constructor
    Complex(float r,float i);
    //Constructor with parameters
    Complex(const Complex &c);
    //Copy constructor
    ~Complex();
    //Destructor
    Complex Conjugate();
    //Conjugate
    Complex add(Complex);
    Complex subtract(Complex);
    Complex multiply(Complex);
    Complex operator+(Complex &);
    Complex operator-(Complex &);
    Complex operator*(Complex &);
    Complex& operator=(Complex &);
    friend std::ostream& operator << (std::ostream& os,const Complex& complex);
    friend std::istream& operator >> (std::istream& is, Complex& complex);
    //Methods for operations

};

#endif // COMPLEX_H_INCLUDED
