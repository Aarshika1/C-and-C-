//CH-230-B
//a13_p2.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<cmath>
#include<fstream>
#include "Complex.h"
using namespace std;
int main()
{
    float f1,f2,f3,f4;
    ifstream infile,infile2;
    ofstream outfile;
    infile.open("in1.txt");
    if(!infile)
    {
        std::cerr<<"Failure..."<<std::endl;
        exit(1);
    }
    //Opening the input file
    while(infile >> f1 >> f2)
    {
        cout << "First Complex: ";
    }
    //Reading two floats from the file
    Complex c1(f1,f2);
    //Calling parametric constructor for comlex using the floats
    cout << c1;
    //Printing the complex
    infile2.open("in2.txt");
    if(!infile2)
    {
        std::cerr<<"Failure..."<<std::endl;
        exit(1);
    }
    //Opening second input file
    while(infile2 >> f3 >> f4)
    {
        cout<<"Second Complex: ";
    }
    Complex c2(f3,f4);
    cout << c2;
    //Making another complex using the same method
    cout << "Sum: ";
    Complex add = c1 + c2;
    cout << add;
    cout << "Difference: ";
    Complex sub = c1 - c2;
    cout << sub;
    cout << "Product: ";
    Complex mul = c1 * c2;
    cout << mul;
    //Doing the opration son the complexes using the overlaoded
    //operators
    outfile.open("output.txt");
    if(!outfile)
    {
        cerr<<"Failure..."<<endl;
    }
    //Opening the output file
    outfile <<"First complex: "<<c1 <<"Second complex: "<< c2 << 
            "Sum: "<<add <<"Difference: "<< sub <<"Product: "<< mul << endl;
            //Writing the results in the output file

    infile.close();
    infile2.close();
    outfile.close();
    //Closing the input file
    return 0;
}

// {
//     float R1,I1,R2,I2;
//     cout<<"Real part of the first complex: ";
//     cin>>R1;
//     cout<<"Imaginary part of the first complex: ";
//     cin>>I1;
//     cout<<"Real part of the second complex: ";
//     cin>>R2;
//     cout<<"Imaginary part of the second complex: ";
//     cin>>I2;
//     //Reading the input
//     Complex c1,c2;
//     //making two instances
//     c1.setcomplex(R1,I1);
//     //Setting first instance
//     c2.setcomplex(R2,I2);
//     //Setting second instance
//     Complex c1_cnj;
//     c1_cnj = c1.Conjugate();
//     //Calling conjugate function on the first instance
//     c1_cnj.printComplex();
//     //printing the conjugate
//     Complex c3;
//     c3 = c1.add(c2);
//     //Calling the addition function
//     c3.printComplex();
//     //printing the addition
//     Complex c4;
//     c4 = c2.subtract(c1);
//     //Calling the subtraction function
//     c4.printComplex();
//     //printing the subtraction
//     Complex c5;
//     c5 = c1.multiply(c2);
//     //calling the multiplication function
//     c5.printComplex();
//     //printing the multiplication
//     return 0;
// }
