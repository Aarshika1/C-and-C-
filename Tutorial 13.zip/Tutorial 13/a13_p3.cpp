//CH-230-B
//a13_p3.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include <string>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

using namespace std;

int main()
{
    int n;
    cout<<"Enter the number of files: ";
    cin>>n;
    //Reading the number of the files to be concatenated

    ifstream infile;
    ofstream outfile;
    outfile.open("concatn.txt",ios::out | ios::app | ios::binary);
    if(!outfile)
    {
        cout << "Failure..." << endl;
        exit(1);
    }
    //Creating an output file
    char name_files[n][100];
    //Creating an array of the files
    char temp[100];
    //creating a temporary array

    for(int i=0; i<n; i++)
    {
       cout<<"Enter " << i+1<<" file: ";
       scanf("%s", temp);
       strcpy(name_files[i], temp);
    }
    //Reading the element of the temperoray array and copying to
    //the names_files array

    string line;
    for(int i=0; i<n; i++)
    {
        infile.open(name_files[i]);
        if(!infile)
        {
            cout << "Failure..." << endl;
            exit(1);
        }
        while(!infile.eof())
        {
            getline(infile, line);
            outfile << line;
        }
        outfile << "\n";
        infile.close();
        //Closing the input files
    }
    //Using a for loop, opening the input files and writing the 
    //content to the output files

    outfile.close();
    //Closing the output file

    return 0;
}