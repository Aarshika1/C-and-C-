//CH-230-B
//a13_p8.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<exception>
using namespace std;

class OwnException : public exception
{
    virtual const char* what() const throw()
    {
        return "Default case exception";
    }
    public:
    string what(){
        return "Default constructor";
        //what() method
    }
};
//Making a class Ownexception

void function(int i)
{
    char a = 'a';
    int b = 12;
    bool c = true;
    OwnException d;
    if(i==1)
        throw a;
    if(i==2)
        throw b;
    if(i==3)
        throw c;
    else
        throw d;
}
//Function to throw the different values
int main()
{
    OwnException d;
    try
    {
        function(1);
    }
    catch(char a)
    {
        std::cerr<<"Caught in main: "<<a<<"\n";
    }
    //Trying and catching the fucntion for parameter 1
    try
    {
        function(2);
    }
    catch(int b)
    {
        std::cerr<<"Caught in main: "<<b<<"\n";
    }
    //Trying and catching the fucntion for parameter 2
    try
    {
        function(3);
    }
    catch(bool c)
    {
        std::cerr<<"Caught in main: "<<c<<"\n";
    }
    //Trying and catching the fucntion for parameter 3
    try
    {
        function(15);
    }
    catch(...)
    {
        std::cerr <<"Caught in main: "<< d.what() << '\n';
    }
    //Trying and catching the fucntion for any other parameter
    return 0;
    
}