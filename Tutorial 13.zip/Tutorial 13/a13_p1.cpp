//CH-230-B
//a13_p1.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<fstream>
#include<cstdlib>
#include<string.h>

int main()
{
    std::ofstream fileo;
    std::ifstream filei;
    //Declaring as input and output files
    std::string input;
    std::string output;
    //Declaring strings
    char c1;
    std::cout<<"File to be copied: ";
    std::cin>>input;
    //Taking the input
    size_t index = input.find_last_of(".");
    std::string temp = input.substr(0,index);
    //Removing the extension from the file name

    output = temp + "_copy"+".txt";
    //Concatenating the copy and extension txt
    filei.open(input);
    //Opening input file
    if(filei.fail())
    {
        std::cerr<<"No file exits..."<<std::endl;
        exit(1);
    }
    //If file fails then printing error
    fileo.open(output);
    //Opening output file
    if(fileo.fail())
    {
        std::cerr<<"No file can be created..."<<std::endl;
        exit(1);
    }
    //if file fails then printing error
    while(filei.get(c1))
    {
        std::cout<<c1;
        if(c1=='\n')
        {
            continue;
        }
        fileo << c1;
    }
    //getting the input from the input file 
    //and puuting in the output file
    std::cout<<"\nFile copied !!!";
    filei.close();
    fileo.close();
    //closing the files
    return 0;
}