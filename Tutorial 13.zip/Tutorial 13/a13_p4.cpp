//CH-230-B
//a13_p4.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
using namespace std;
 
class A
{
  int x;
public:
  void setX(int i) {x = i;}
  void print() { cout << x; }
};
 
class B:virtual public A
{
public:
  B()  { setX(10); }
};
//Setting inheritance to virtual
 
class C:virtual public A  
{
public:
  C()  { setX(20); }
};
//Setting inheritance to virtual
 
class D: public B, public C {
};
 
int main()
{
    D d;
    d.print();
    return 0;
}


// Errrors received are:-
// a13_p4.cpp: In function 'int main()':
// a13_p4.cpp:36:7: error: request for member 'print' is ambiguous
//      d.print();
//        ^~~~~
// a13_p4.cpp:13:8: note: candidates are: void A::print()
//    void print() { cout << x; }
//         ^~~~~
// a13_p4.cpp:13:8: note:                 void A::print()

// Reason of the errors is that Class D is having multiple inheritance
// from Class B and Class C which are further inherited from Class D 
// and becaue of it the method print() of class D is inherited twice in 
// Class D which in turn creates ambuguity as stated in the errors

// Solution-
// Using virtual in front of the inheritance will solve the error
// because it will then create only one subobject.