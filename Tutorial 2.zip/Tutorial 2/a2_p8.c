/*
   CH-230-B
   a2_p8.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    int Integer;

    scanf("%d",&Integer);
    if (Integer%2==0 && Integer%7==0)
        /*The condition for the divisibility test*/
    {
        printf("The number is divisible by 2 and 7\n");

    }
    else
    {
        printf("The number is NOT divisible by 2 and 7\n");
    }
}
