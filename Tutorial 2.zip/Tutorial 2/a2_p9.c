/*
   CH-230-B
   a2_p9.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    char Char;

    scanf("%c",&Char);
    if ((Char>='a' && Char<='z') || (Char>='A' && Char<='Z'))
    /* Using relational and boolean operators*/
    {
        printf("%c is a letter\n",Char);

    }
    else if (Char>='0' && Char<='9')
    {
        printf("%c is a digit\n",Char);
    }
    else
    {
        printf("%c is some other symbol\n",Char);
    }
    return 0;
}
