#include<stdio.h>
int main()
{
    double Double_one;
    double Double_two;

        scanf("%lf",&Double_one);
        getchar();

        scanf("%lf",&Double_two);
        getchar();

        printf("sum of doubles=%lf\n",Double_one+Double_two);
        printf("difference of doubles=%lf\n", Double_one-Double_two);
        printf("square=%lf\n",Double_one*Double_one);


    int Integer_one;
    int Integer_two;

        scanf("%d",&Integer_one);
        getchar();

        scanf("%d",&Integer_two);
        getchar();


        printf("sum of integers=%d\n",Integer_one+Integer_two);
        printf("product of integers=%d\n",Integer_one*Integer_two);

    char First_char;
    char Second_char;

        scanf("\n%c",&First_char);
        getchar();

        scanf("\n%c",&Second_char);
        getchar();

        printf("sum of chars=%d\n",First_char+Second_char);
        printf("product of chars=%d\n",First_char*Second_char);

        printf("sum of chars=%c\n",First_char+Second_char);
        printf("product of chars=%c\n",First_char*Second_char);





        return 0;


}
