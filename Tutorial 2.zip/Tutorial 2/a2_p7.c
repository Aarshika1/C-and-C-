/*
   CH-230-B
   a2_p7.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    int i=8;
    while(i>=4)
    {
        printf("i is %d\n",i);
        i-=1;
    }
    /* The curly brackets for the while loop was missing*/
    printf("That's it");
    return 0;
}
