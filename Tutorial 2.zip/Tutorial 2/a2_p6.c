/*
   CH-230-B
   a2_p6.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    double x,y;
    printf("Enter a value for x:");
    scanf("%lf",&x);

    printf("Enter a value for y:");
    scanf("%lf",&y);
    double *ptr_one,*ptr_two,*ptr_three;
    /*Declaring three pointers*/
    ptr_one=&x;
    ptr_two=&x;
    ptr_three=&y;
    /*Pointing the pointers to x and y*/
    printf("The address of x by ptr_one is %p\n",ptr_one);
    printf("The address of x by ptr_two is %p\n",ptr_two);
    printf("The address of y by ptr_three is %p\n",ptr_three);
    return 0;
}
