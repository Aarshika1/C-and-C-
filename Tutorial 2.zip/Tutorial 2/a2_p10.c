/*
   CH-230-B
   a2_p10.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    int n;
    int i=1;

    printf("Enter an integer n:");
    scanf("%d",&n);
    while(n<=0)
    {
        printf("Enter an integer n:");
        scanf("%d",&n);
    }
    /*If the value of n is 0 or negative then the next loop will get executed*/

    while(i<=n)
    {
        printf("%d days=%d hours\n",i,i*24);
        i++;

    }
    /*The while loop will continue till the condition of i being
    less than or equal to n is satisfied*/



    return 0;
}
