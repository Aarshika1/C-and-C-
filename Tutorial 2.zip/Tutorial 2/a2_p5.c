/*
   CH-230-B
   a2_p5.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    int a;
    printf("Enter a value for a:");
    scanf("%d",&a);
    int *ptr_a;
    /*Declaring a pointer*/
    ptr_a=&a;
    /*Pointing the pointer to a */
    printf("The value of a is %d\n",a);
    printf("The address of a is %p\n",ptr_a);
    *ptr_a=*ptr_a+5;
    printf("The modified value of a is %d\n",a);
    printf("The modified address of a is %p",ptr_a);
    /*The address will remain the same*/
    return 0;

}
