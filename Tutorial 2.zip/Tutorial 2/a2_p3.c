#include<stdio.h>
int main()
{
    int Weeks;
    int Days;
    int Hours;
    printf("Enter the number of weeks:");
    scanf("%d",&Weeks);
    printf("Total number of hours in %d is %d\n",Weeks,Weeks*7*24);
    getchar();
    printf("Enter the number of days:");
    scanf("%d",&Days);
    printf("Total number of hours in %d is %d\n",Days,Days*24);
    getchar();
    printf("Enter the number of hours:");
    scanf("%d",&Hours);
    printf("Total hours in %d is %d", Hours,Hours);
    return 0;

}
