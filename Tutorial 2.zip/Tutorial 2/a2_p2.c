#include<stdio.h>
int main()
{
    char Character;

    scanf("%c",&Character);
    printf("character=%c\n",Character);
    printf("decimal=%d\n",Character);
    printf("octal=%o\n",Character);
    printf("hexadecimal=%x\n",Character);
    return 0;


}
