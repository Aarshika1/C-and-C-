/*
   CH-230-B
   a5_p10.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
void recursive(int n);
/*Declaring function*/
int main()
{
    int n;
    printf("Enter an integer:");
    scanf("%d",&n);
    /*Reading the string from the keyboard*/
    recursive(n);
    /*Calling the function*/
    return 0;
}
void recursive(int n)
{
    if(n>=1)
    {
        printf("%d ",n);
        recursive(n-1);
    }
}
/*The above function takes in an integer
and by recursion prints the value of all the
predecessors of n till 1*/
