/*
   CH-230-B
   a5_p6.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int count(float *arr)
{
    int count = 0;
    while(*arr)
    {
        if(*arr>=0)
        {
            count++;
        }
        else if(*arr<0)
        {
            break;
        }
        arr++;
    }
    return count;
}
int main()
{
    int size,i,j;
    printf("Enter the size of the array:");
    scanf("%d",&size);
    /*Scanning the size of the array*/
    float array[size];
    for(i=0;i<size;i++)
    {
        printf("Enter the %d float:",(i+1));
        scanf("%f",&array[i]);
    }
    for(int i=0;i<size;i++)
    {
        if(array[i]>=0)
        {
            printf("%f ",array[i]);
        }
        else if(array[i]<0)
        {
            break;
        }
    }
    printf("\n");
    int result = count(array);
    printf("%d",result);
    return 0;
//    /*Scanning the elements of the array*/
//    float *ptr_1=array;
//    float *ptr_2=array;
//    /*Declaring two pointers*/
//    for(j=0;j<size;j++)
//    {
//        if(array[j]>0)
//        {
//            ptr_2++;
//        }
//        /*Incrementing the value of the pointer by 1*/
//        if(array[j]<0)
//        {
//            break;
//        }
//        /*Breaking the loop, if the elements encountered
//        negative*/
//    }
//
//    printf("Before the first negative value: %ld elements",(ptr_2-ptr_1));
//    /*Printing the number of the elements before the first negative element*/

return 0;
}
