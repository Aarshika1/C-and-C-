/*
   CH-230-B
   a5_p8.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<stdlib.h>
/*Including libraries*/
void readMatrix(int **array, int sizer, int sizec);
void printMatrix(int **array, int sizer, int sizec);
void productMatrix(int **array_1, int **array_2,int **array_pro, int size_1,int size_2, int size_3);
/*Declaring functions*/
int main()
{
    int m,n,p,i,j,k;
    scanf("%d",&n);
    scanf("%d",&m);
    scanf("%d",&p);
    /*Reading dimension of the functions*/
    int **matrix_1,**matrix_2,**matrixpro;
    matrix_1=(int**)malloc(sizeof(int*)*n);
    /*Allocating memory to the first multidimensional
    array*/
    for(i=0;i<n;i++)
    {
        matrix_1[i]=(int*)malloc(sizeof(int)*m);
        /*Allocating memory*/
    }
    matrix_2=(int**)malloc(sizeof(int*)*m);
    /*Allocating memory to second multidimensional array*/
    for(j=0;j<m;j++)
    {
        matrix_2[j]=(int*)malloc(sizeof(int)*p);
        /*Allocating memory*/
    }
    readMatrix(matrix_1,n,m);
    readMatrix(matrix_2,m,p);
    /*Calling the function to read the matrices*/
    printf("Matrix A:\n");
    printMatrix(matrix_1,n,m);
    printf("Matrix B:\n");
    printMatrix(matrix_2,m,p);
    /*Calling the function to print the
    matrices*/
    printf("The multiplication result AXB:\n");
    matrixpro=(int**)malloc(sizeof(int*)*n);
    for(k=0;k<n;k++)
    {
        matrixpro[k]=(int*)malloc(sizeof(int)*p);
    }
    /*Allocating memory to the third array*/
    productMatrix(matrix_1,matrix_2,matrixpro,n,m,p);
    /*Calling the function to print the product of the
    matrices */
    for(i=0;i<n;i++)
    {
        free(matrix_1[i]);
    }
    free(matrix_1);
    for(j=0;j<m;j++)
    {
        free(matrix_2[j]);
    }
    free(matrix_2);
    for(k=0;k<n;k++)
    {
        free(matrixpro[k]);
    }
    free(matrixpro);
    /*Freeing the memory*/

return 0;

}
void readMatrix(int **array, int sizer, int sizec)
{
    int i,j;
    for(i=0;i<sizer;i++)
    {
        for(j=0;j<sizec;j++)
        {
            scanf("%d",&array[i][j]);
        }
    }
}
/*The above function takes in a two dimensional array and
its two dimensions and then reads the elements of the array
using nested for loop*/

void printMatrix(int **array, int sizer, int sizec)
{
    int i,j;
    for(i=0;i<sizer;i++)
    {
        for(j=0;j<sizec;j++)
        {
            printf("%d ",array[i][j]);
        }
        printf("\n");
    }
}
/*The above functions takes in a two dimensional array and
its two dimensions and then prints the elements of the array
using nested for loop*/
void productMatrix(int **array_1, int **array_2,int **array_pro, int size_1,int size_2, int size_3)
{
    int i,j,k;
    for(i=0;i<size_1;i++)
    {
        for(j=0;j<size_3;j++)
        {
            int sum=0;
            for(k=0;k<size_2;k++)
            {
                sum=sum+(array_1[i][k]*array_2[k][j]);
            }
            array_pro[i][j]=sum;
        }
    }
    for(i=0;i<size_1;i++)
    {
        for(j=0;j<size_3;j++)
        {
            printf("%d ",array_pro[i][j]);
        }
        printf("\n");
    }
}
/*The above function takes in two two dimensional arrays and
their dimensions.It also declares a third array which is the
product of the two arrays. And then it declares an integer sum
which is the sum of the product of the element of the first and
the second array.It prints the value of the third matrix.The
function is void, and doesn't return anything*/

