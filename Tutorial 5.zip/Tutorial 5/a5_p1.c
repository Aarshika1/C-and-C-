/*
   CH-230-B
   a5_p1.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
void table(int n,char c);
/*Declaring a function*/
int main()
{
    int n;
    char c;
    scanf("%d",&n);
    getchar();
    /*Scanning the integer*/
    scanf("%c",&c);
    table(n,c);
    /*Scanning the character*/

    return 0;
}
void table(int n,char ch)
{
    int i,j;
    for(i=n;i>=1;i--)
    {
        for(j=0;j<i;j++)
        {
            printf("%c",ch);
        }
        printf("\n");
    }
}
/*The above function takes in an integer and a character and
prints the given character in the form of the rows and columns
using nested for loops*/
