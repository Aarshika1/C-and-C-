/*
   CH-230-B
   a5_p11.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int Prime(int num,int divisor);
/*Declaring the function*/
int main()
{
    int x,p;
    scanf("%d",&x);
    /*Scanning the integer*/
    p = Prime(x,x/2);
    /*Calling the function*/
    if(p==1)
    {
        printf("%d is prime\n",x);
    }
    /*If the function returns 1, then the integer
   is prime*/

    else
    {
       printf("%d is not prime\n",x);
    }
   /*Otherwise is integer is not prime*/

return 0;
}

int Prime(int num,int divisor)
{
    if(num==1)
    {
        return 0;
    }
    /*Special condition if the number is 1.
    1 is not a prime number*/
    if(divisor==1)
    {
         return 1;
    }
       else
    {
       if(num%divisor==0)
       {

           return 0;
       }

        else
        {
            return Prime(num,divisor-1);
        }

    }
}

/*The above function takes in two integers and checks
if the divisor is equal to 1, then the number will trivially
be prime. Else, if the remainder of the number and the divisor
is zero, then the divisor is the factor of the integer and
the integer is not prime. Otherwise the integer is prime.*/
