/*
   CH-230-B
   a5_p4.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<stdlib.h>
/*including the libraries*/
void divby5(float arr[], int size);
/*Declaring the function*/
int main()
{
    int i,n;
    printf("Enter the size of the array: ");
    scanf("%d",&n);
    /*Reading the size of the array*/
    float *array;
    array = (float*)malloc(sizeof(float)*n);
    /*Allocating the memory to the array*/
    if(array == NULL)
    {
        exit(1);
    }
    /*If the string is empty the no memory is allocated*/
    for(i=0;i<n;i++)
    {
        printf("Enter the %d float ",(i+1));
        scanf("%f",&array[i]);

    }
    /*Reading the elements of the array*/
    printf("Before:\n");
    for(i=0;i<n;i++)
    {
        printf("%.3f ",array[i]);
    }
    /*printing the array before division*/
    printf("\nAfter:\n");
    divby5(array,n);
    for(i=0;i<n;i++)
    {
        printf("%.3f ",array[i]);
    }
    /*Printing the array after division*/
    free(array);
    /*Freeing the memory*/

    return 0;
}
void divby5(float arr[], int size)
{
    int a;
    for(a=0;a<size;a++)
    {
        arr[a]=arr[a]/5;
    }

}
/*The above function takes in a float array and an integer
as the size of the array. It replaces all the elements of the
array by new elements after dividing them by. being a void function
it returns nothing*/
