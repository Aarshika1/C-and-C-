/*
   CH-230-B
   a5_p7.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
/*Including libraries*/
int main()
{
    char str_1[100],str_2[100];
    char *concatenation;
    int i,j,a;
    fgets(str_1,100,stdin);
    /*Reading string 1*/
    for(a=0;a<100;a++)
    {
        if(str_1[a]=='\n')
        {
            str_1[a]='\0';
        }
    }
    /*If any character of the first string is \n
    then replacing it with \0*/
    fgets(str_2,100,stdin);
    /*Reading string 2*/

    i=strlen(str_1);
    j=strlen(str_2);
    /*Computing the length of the strings*/
    concatenation = (char*) malloc (sizeof(char)*(i+j));
    /*Allocating memory*/
    concatenation = strcat(str_1,str_2);
    /*Concatenating the strings*/
    if(concatenation == NULL)
    {
        exit(1);
    }
    /*If the string is empty then no memory is allocated*/
    printf("Result of concatenation: %s",concatenation);
    /*Printing the result*/
    return 0;

}
