#include<stdio.h>
void divby5(float arr[], int size);
int main()
{
    int i,size;
    printf("Enter the size of the array: ");
    scanf("%d",&size);
    float arr[size];
    divby5(arr,size);

    return 0;
}
void divby5(float arr[], int size)
{
    int a,b;
    float arr_new[size];
    for(a=0;a<size;a++)
    {
        printf("Enter the %d integer ",(a+1));
        scanf("%f",&arr[a]);

    }
    printf("Before:\n");
    for(a=0;a<size;a++)
    {
        printf("%.3f ",arr[a]);
    }
    printf("\nAfter:\n");
    for(a=0;a<size;a++)
    {
        arr[a]=arr[a]/5;
        printf("%.3f ",arr[a]);
    }

}


