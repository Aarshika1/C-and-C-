/*
   CH-230-B
   a5_p9.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<stdlib.h>
/*Including libraries*/
int main()
{
    int rows,columns,depth,i,j,k;
    scanf("%d",&rows);
    scanf("%d",&columns);
    scanf("%d",&depth);
    /*Scanning the dimension of the array*/
    int ***array;
    array = (int***)malloc(sizeof(int**)*rows);
    /*Allocating memory to the multidimensional array*/
    if(!array)
    {
        exit(1);
    }
    /*If the array is empty then no memory allocated*/
    for(i=0;i<rows;i++)
    {
        array[i]= (int**)malloc(sizeof(int*)*columns);
        /*Allocating memory*/
        if(!array[i])
        {
            exit(1);
        }
        /*If the array is empty then no memory allocated*/
        for(j=0;j<columns;j++)
        {
            array [i][j] = (int*)malloc(sizeof(int)*depth);
            /*Allocating memory*/
            if(!array[i][j])
            {
                exit(1);
            }
            /*No memory allocated, if array is empty*/
            for(k=0;k<depth;k++)
            {
                scanf("%d",&array[i][j][k]);
                /*Scanning the elements of the array*/
            }
        }
    }
    for(i=0;i<depth;i++)
    {
        printf("Section %d:\n",i+1);
        for(j=0;j<rows;j++)
        {
            for(k=0;k<columns;k++)
            {
                printf("%d ",array[j][k][i]);
                /*Printing the section of the array*/
            }
           printf("\n");
           /*Printing a new line*/
        }

    }
    for(i=0;i<rows;i++)
    {
        for(j=0;j<columns;j++)
        {
            free(array[i][j]);
        }
        free(array[i]);
    }
    free(array);
    /*Freeing the memory*/

return 0;
}
