/*
   CH-230-B
   a5_p2.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
void divby5(float arr[], int size);
/*Declaring a function*/
int main()
{
    int i;
    int size=6;
    float arr[]={5.5,6.5,7.75,8.0,9.6,10.36};
    /*Putting in the values in the array*/
    printf("Before:\n");
    for(i=0;i<size;i++)
    {
        printf("%.3f ",arr[i]);
    }
    /*Printing the array before the division*/

    printf("\nAfter:\n");
    divby5(arr,size);
    /*Calling the function*/
    for(i=0;i<size;i++)
    {
        printf("%.3f ",arr[i]);
    }
    /*Printing the array after the division*/
    printf("\n");
    return 0;
}
void divby5(float arr[], int size)
{
    int a;
    for(a=0;a<size;a++)
    {
        arr[a]=arr[a]/5;
    }

}
/*The above function takes in an array and its size
and replaces the elements of the array by a new element
by dividing the previous element by 5*/
