/*
   CH-230-B
   a5_p.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
double product_scaler(int n, double v[], double w[]);
void position_gv(int n, double v[]);
void position_lv(int n, double v[]);
void position_gw(int n, double w[]);
void position_lw(int n, double w[]);
/*Declaring the functions*/
int main()
{
    int n,i;
    scanf("%d",&n);
    double v[n],w[n];
    /*Reading the size of the arrays from the keyboard*/
    for(i=0;i<n;i++)
    {
        scanf("%lf",&v[i]);
    }
    /*Scanning the elements for v*/
    for(i=0;i<n;i++)
    {
        scanf("%lf",&w[i]);
    }
    /*Scanning the elements for w*/
    printf("Scalar product=%lf\n",product_scaler(n,v,w));
    /*Printing the scaler product in the main function*/
    position_lv(n,v);
    position_gv(n,v);
    position_lw(n,w);
    position_gw(n,w);
    /*Calling the void functions*/
    return 0;

}
double product_scaler(int n, double v[50], double w[50])
{
    int a;
    double pro;
    double s_pro=0;
    for(a=0;a<n;a++)
    {
        pro=v[a]*w[a];
        s_pro=s_pro+pro;
    }
    return s_pro;
}
/*the above function takes in an integer and two
float arrays. It first calculates the product of the
two arrays and then computes the sum of all the products
to compute the scaler product of the two vectors*/

void position_gv(int n, double v[50])
{
    int a;
    int pos=0;
    double greatest=v[0];
    for(a=0;a<n;a++)
        {
        if(v[a]>greatest)
        {
            greatest=v[a];
            pos=a;

        }
        }
        printf("The largest = %lf\n",greatest);
        printf("Position of largest = %d\n",pos);
}
/*the above function takes in an integer and an array
and first initializes the greatest float to be
the first element and then compares the greatest float
to the other elements. If the element is greater than
the greatest float then the element becomes the greatest
float. It increments the value of position by 1 and prints the
value of the greatest float and the position of the float*/
void position_lv(int n, double v[50])
{
    int a;
    int pos=0;
    double lowest=v[0];
    for(a=0;a<n;a++){
        if(v[a]<lowest)
        {
            lowest=v[a];
            pos=a;

        }
    }
    printf("The smallest = %lf\n",lowest);
    printf("Position of smallest = %d\n",pos);
}
/*the above function takes in an integer and an array
and first initializes the lowest float to be
the first element and then compares the lowest float
to the other elements. If the element is less than
the lowest float then the element becomes the lowest
float. It increments the value of position by 1 and prints the
value of the lowest float and the position of the float*/

void position_gw(int n, double w[50])
{
    int a;
    int pos=0;
    double greatest=w[0];
    for(a=0;a<n;a++)
    {
        if(w[a]>greatest)
        {
            greatest=w[a];
            pos=a;
        }
    }
    printf("The largest = %lf\n",greatest);
    printf("Position of largest = %d\n",pos);
}
/*the above function takes in an integer and an array
and first initializes the greatest float to be
the first element and then compares the greatest float
to the other elements. If the element is greater than
the greatest float then the element becomes the greatest
float. It increments the value of position by 1 and prints the
value of the greatest float and the position of the float*/

void position_lw(int n, double w[50])
{
    int a;
    int pos=0;
    double lowest=w[0];
    for(a=0;a<n;a++)
    {
        if(w[a]<lowest)
        {
            lowest=w[a];
            pos=a;
        }

    }
    printf("The smallest = %lf\n",lowest);
    printf("Position of smallest = %d\n",pos);
}
/*the above function takes in an integer and an array
and first initializes the lowest float to be
the first element and then compares the lowest float
to the other elements. If the element is less than
the lowest float then the element becomes the lowest
float. It increments the value of position by 1 and prints the
value of the lowest float and the position of the float*/
