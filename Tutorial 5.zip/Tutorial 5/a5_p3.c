/*
   CH-230-B
   a5_p3.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<string.h>
#include<ctype.h>
/*Including libraries*/
int count_lower(char *str);
/*Declaring function*/
int main(){

    while(1)
    {
        char string[50];
        printf("Enter a string:");
        fgets(string,50,stdin);
        /*Reading the string from the keyboard*/
        if(strcmp(string,"\n")==0)
        {
            break;
        }
        /*If the entered string is empty then the program will
        terminate.*/
        printf("Number of lowercase characters is %d\n",count_lower(string));
        /*Calling the function*/
    }
    return 0;
}
int count_lower(char *str)
{
    int l_char=0;
    while(*str)
    {
        if(islower(*str)>0)
        {
            l_char++;
        }

        str++;
    }
    return l_char;
}
/*The above function takes in the value of a string and checks if
any character is lower case. If yes, it increases the value
of the count of the number of lower characters by 1 and returns
an integer value.*/
