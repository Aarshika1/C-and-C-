/*
   CH-230-B
   a3_p4.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include <stdio.h>
int position(char str[], char c)
{
int idx;
/* Loop until end of string */
for (idx = 0; str[idx] != c && str[idx] != '\0';++idx);

    /*The missing semicolons were the reason of the wrong output
    because the loop is empty*/

/* do nothing */
return idx;

}
int main() {
char line[80];
while (1) {
printf("Enter string:\n");
fgets(line, sizeof(line), stdin);
printf("The first occurrence of 'g' is: %d\n", position(line, 'g'));
}
}
