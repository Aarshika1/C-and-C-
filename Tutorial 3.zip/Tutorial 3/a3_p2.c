/*
   CH-230-B
   a3_p2.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    char ch;
    int n;
    int i=1;
    printf("Enter a lower case character:");
    scanf("%c",&ch);
    /*Reading the value of the character*/
    printf("Enter an integer:");
    scanf("%d",&n);
    /*Reading the value of the integer*/
    printf("%c\n",ch);
    while(i<=n)
    {
        printf("%c-%d\n",ch,i);
        i++;
    }
    /*Use of while loop to print the value till the integer i
    initialized to be 1 is less than or equal to n*/
    return 0;

}
