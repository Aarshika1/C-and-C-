/*
   CH-230-B
   a3_p5.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    int i,n;
    char c;
    double Temp_in_celsius[100],Temp_in_Fahrenheit,mean,sum=0;
    /*Declaring the variables*/
    printf("Enter a character:");
    scanf("%c",&c);
    printf("Enter an integer:");
    scanf("%d",&n);
    /*Taking input from the keyboard*/
    for (i=0;i<n;i++)
    {
        printf("Enter the value for the temperature %d:",i+1);
        scanf("%lf",&Temp_in_celsius[i]);
    }
    /*Taking input for the array*/
    switch (c){
    case 's':
        for(i=0;i<n;i++){
            sum=sum+Temp_in_celsius[i];
            }
        printf("Sum of the Temperatures=%lf\n",sum);
        break;
        /*Calculating the sum*/
    case 'p':
        for (i=0;i<n;i++){
        printf("%lf\n",Temp_in_celsius[i]);
        }
        break;
        /*Printing the array*/
    case 't':
        for(i=0;i<n;i++){
            Temp_in_Fahrenheit=(((9*Temp_in_celsius[i])/5)+32);
            printf("%lf\n",Temp_in_Fahrenheit);
            }
        break;
        /*Converting the temperature into Fahrenheit*/
    default:

        for(i=0;i<n;i++){
            sum=sum+Temp_in_celsius[i];
            mean=sum/n;
            }
        printf("%lf",mean);
        break;
        /*Calculating the mean*/

        }
return 0;
}



