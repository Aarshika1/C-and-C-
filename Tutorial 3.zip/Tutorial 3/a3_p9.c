#include<stdio.h>
double sum25(double v[],int n);
/*Declaring a function*/
double sum_25;
int main()

{
    int n,i;
    double v[20],sum;
    /*Declaring variables*/
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%lf",&v[i]);
    }
    /*Reading the array from the keyboard*/
    sum= sum25(v,n);
    if(sum!=-111.0){
    printf("sum=%lf\n",sum);
    }
    return 0;

}
double sum25(double v[],int n)
/*Defining the function*/
{
    if(n>5){
        sum_25=v[2]+v[5];
        return sum_25;
        /*If the input is valid*/
    }
    else{
        printf("One or both positions are invalid\n");
        return -111;
        /*If the input is invalid*/
    }
}
