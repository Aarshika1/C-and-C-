/*
   CH-230-B
   a3_p1.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    float x;
    int n;
    int i=1;
    scanf("%f",&x);
    scanf("%d",&n);
    while(n<=0)
    {
        printf("Input is invalid, reenter value\n");
        scanf("%d",&n);
    }
    /* While loop for invalidating negative or zero value of integer n*/
    while (i<=n)
    {
        printf("%f\n",x);
        i++;
    }
    /*Printing the value of x n times*/
    return 0;

}
