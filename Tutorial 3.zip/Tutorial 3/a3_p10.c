/*
   CH-230-B
   a3_p10.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
float product(float a,float b);
void productbyref(float a,float b,float *p);
void modifybyref(float *a,float *b);
/*Declaring functions*/
float a,b,c;

int main(){
    scanf("%f",&a);
    scanf("%f",&b);
    /*Reading the floats from the keyboard*/
    printf("Product of the two floats=%f\n",product(a,b));
    productbyref(a,b,&c);
    printf("Product of the two floats by reference=%f\n",c);
    /*The value of the first two function is same*/
    modifybyref(&a,&b);
    printf("Modified value of a:%f\nModified value of b:%f\n",a,b);
    /*Using the declared functions to calculate and modify*/
    return 0;

}
float product(float a,float b)
/*Defining the function*/
{
    float product;
    product=a*b;
    return product;
}
void productbyref(float a,float b,float *p)
/*Defining the function*/
{
    *p=a*b;
    /*No return value because the function has void return*/
}
void modifybyref(float *a,float *b)
/*Defining the function*/
{
    *a=*a+3;
    *b=*b+11;
    /*No return value because the function has void return*/

}
