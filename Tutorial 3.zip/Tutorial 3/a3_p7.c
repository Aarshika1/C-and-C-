/*
   CH-230-B
   a3_p5.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include <stdio.h>
void print_form(int n, int m, char c);
/*Declaring a function*/
int n, m;
char c;
/*Declaring integer and character according to question*/
int main()
{
scanf("%d", &n);
scanf("%d", &m);
getchar();
scanf("%c", &c);
/*Reading the values from the keyboard*/
printf("\n");
print_form(n,m,c);
return 0;

}
void print_form(int n, int m, char c)
/*Defining the self declared function*/
{
    int row,column;
    for(row=1; row<=n; row++)
    {
        for(column=1; column<(m+row); column++)
        {
            printf("%c",c);
        }
         printf("\n");
    }
    /*Nested 'for' loop*/


    return;
    /*It returns nothing being void*/
}


