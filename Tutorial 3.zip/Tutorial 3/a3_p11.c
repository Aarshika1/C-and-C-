/*
   CH-230-B
   a3_p11.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<string.h>

int main()
{
    char one[100];
    char two[100];
    char copy[100];
    char c;
    int i,h,k,a,b;
    /*Declaring variables*/
    fgets(one,sizeof(one),stdin);
    fgets(two,sizeof(two),stdin);
    /*Reading the strings from the keyboard*/

    i=strcmp(one,two);

    for(k=0;k<100;k++)
    {
        if(one[k]=='\n')
        {
            one[k]='\0';
        }
    }
    for(h=0;h<100;h++)
    {
        if(two[h]=='\n')
        {
            two[h]='\0';
        }
    }

    a=strlen(one);
    b=strlen(two);
    printf("length1=%d\n",a);
    printf("length2=%d\n",b);
    /*(1)Length of the strings*/
    printf("concatenation=%s\n",strcat(one,two));
    /*(2)Concatenation*/
    printf("copy=%s\n",strcpy(copy,two));
    /*(3)Copying another string*/

    if(i>0)
    {
        printf("one is larger than two\n");
    }
    else if(i<0)
    {
        printf("one is smaller than two\n");
    }
    else
    {
        printf("one is equal to two\n");
    }
    /*(4)Comparing the strings*/
    scanf("%c",&c);
    /*Reading a character from the keyboard*/
    int j,flag=0;
    for(j=0;j<strlen(two);j++)
    {if(two[j]==c)
        {
            flag=1;
            printf("position=%d\n",j);
            break;
        }

    }
    if(flag==1)
    {

    }
    else
    {
        printf("The character is not in the string\n");
    }
    /*(5)Finding the position of the character*/

    return 0;
    }

