/*
   CH-230-B
   a3_p8.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
float number[10];
/*Declaring an array*/
float sum_floats(float number[]);
float average_floats(float number[]);
/*Declaring the functions to calculate sum and average*/
 
int main()
{
    int i;
    float sum_of_floats,average_of_floats;
    for(i=0;i<10;i++)
    {
 
        printf("Enter float value:");
        scanf("%f",&number[i]);
        /*Reading float from the keyboard*/
        if(number[i]==-99.0)
        {
            break;
        }
        /*If input is equal to -99.0, the program would stop
        reading the floats from keyboard*/
 
    }
    sum_of_floats=sum_floats(number);
    average_of_floats=average_floats(number);
    /*Calculating using the self declared functions*/
    printf("Sum of all the floats=%f\n",sum_of_floats);
    printf("Average of all the floats=%f\n",average_of_floats);
    return 0;
}
float sum_floats(float number[])
/*Calling the functions*/
{
    int i;
    int idx=0;
    float sum=0;
    for(i=0;number[idx]!=(-99.0)&&i<10;i++)
        /*Calculating excluding -99.0*/
    {
        sum=sum+number[i];
        idx++;
    }
    return sum;
}
float average_floats(float number[])
/*Calling the function*/
 
{
    int i;
    int idx=0;
    float average,sum=0;
    for(i=0;number[idx]!=-99.0&&i<10;i++)
        /*Calculating excluding -99.0*/
    {
        sum=sum+number[i];
        idx++;
    }
    average = sum/idx;
    return average;
}