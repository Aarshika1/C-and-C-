/*
   CH-230-B
   a3_p6.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
float to_pounds(int kg, int g);

int main()
{
    int kg,g;
    float pounds;
    scanf("%d",&kg);
    scanf("%d",&g);
    /*Reading the values from the keyboard*/
    pounds=to_pounds(kg,g);
    /*Using the self declared function to_pounds
    for further calculations*/
    printf("Result of conversion: %f\n",pounds);
    return 0;
}
float to_pounds(int kg, int g)
{
    float p;
    p=((float)kg*2.2)+(((float)g*2.2)/1000);
    /*Using typecasting to convert int kg
    and g to float for further calculations*/
    return p;
}
