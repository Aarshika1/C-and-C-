/*
   CH-230-B
   a3_p3.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
float convert(int cm);
float km;
int cm;
int main()
    {
        scanf("%d",&cm);
        km= convert(cm);
        /*Using the self declared function convert*/
        printf("Result of conversion: %f\n",km);

        return 0;

    }
float convert(int cm)
    {
        km=(float)cm/100000;
        /* Using typecasting to convert int cm to float
        for the purpose of division.*/
        return km;
    }
    /* Declaration of a function convert, which would do
    the actual conversions.*/
