//CH-230-B
//a11_p1.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include "Box.h"
using namespace std;
int main()
{
    int n;
    cout<<"Enter the number of Boxes: ";
    cin>>n;
    //Reading the integer
    Boxes *array;
    //Decalring an array
    array = new Boxes[2*n];
    //Dynamically allocating the memory to the array
    int i;
    for(i=0;i<n;i++)
    {
        double newheight,newwidth,newdepth;
        cout<<"Enter the height: ";
        cin>>newheight;
        array[i].setHeight(newheight);
        //Taking in the height and setting it
        cout<<"Enter the width: ";
        cin>>newwidth;
        array[i].setWidth(newwidth);
        //Taking in the width and setting it
        cout<<"Enter the depth: ";
        cin>>newdepth;
        array[i].setDepth(newdepth);
        //Taking in the depth and setting it
        double newheight2,newwidth2,newdepth2;
        newheight2=array[i].getHeight();
        newwidth2=array[i].getWidth();
        newdepth2=array[i].getDepth();
        //Getting the parameters
        cout<<"Volume: "<<newheight2*newwidth2*newdepth2<<endl;
        //Calculating and printing the volumes
        Boxes array[i];
        //Calling the copy constructor
    }
    delete []array;
    //Deleting the allocated memory
    return 0;
}
