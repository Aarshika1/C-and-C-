//CH-230-B
//a11_p1.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#ifndef BOX_H_INCLUDED
#define BOX_H_INCLUDED
using namespace std;
class Boxes
{
    private:
    double height;
    double width;
    double depth;
    //Declaring the objects
    public:
    void setHeight(double);
    void setWidth(double);
    void setDepth(double);
    //Declaring the setters
    double getHeight();
    double getWidth();
    double getDepth();
    //Declaring the getters
    Boxes();
    //Default constructor
    Boxes(double,double,double);
    //Constructor
    Boxes(const Boxes&);
    //Copy constructor
    ~Boxes();
    //Destructor
};
#endif // BOX_H_INCLUDED
