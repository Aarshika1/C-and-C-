//CH-230-B
//a11_p1.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include "Box.h"
//Including the header file
using namespace std;

void Boxes::setHeight(double h)
{
    height = h;
}
void Boxes::setWidth(double w)
{
    width = w;
}
void Boxes::setDepth(double d)
{
    depth = d;
}
//Defining the setters for the parameters
double Boxes::getHeight()
{
    return height;
}
double Boxes::getWidth()
{
    return width;
}
double Boxes::getDepth()
{
    return depth;
}
//Defining the getters fro the parameters
Boxes::Boxes()
{
    height=0.0;
    width=0.0;
    depth=0.0;
}
//Default constructor
Boxes::Boxes(double h,double w,double d)
{
    height = h;
    width = w;
    depth = d;
}
//Constructor with parameters
Boxes::Boxes(const Boxes &b)
{
    height = b.height;
    width = b.width;
    depth = b.depth;
}
//Defning the copy constructor
Boxes::~Boxes()
{

}
//Defining the destructor