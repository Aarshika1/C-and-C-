//CH-230-B
//a11_p4.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#ifndef CREATURE_H_INCLUDED
#define CREATURE_H_INCLUDED
#include<string>
using namespace std;
class Creature {
	public:
		Creature();  
		void run() const;

	protected:
		int distance;
};

class Wizard : public Creature {
	public:
		Wizard();
		void hover() const;

	private:
		int distFactor;
};

class Witch : public Creature {
    public:
        Witch();
        void magic() const;
    private:
        int flying;
};
//Making a new creature using the class Creature
//by inheritnace and making an attribute and method

class Programmers : public Creature {
    public:
        Programmers();
        void hack() const;
    private:
        string hacking;
};
//Making a new creature using the class Creature
//by inheritance and making an attribute and method
#endif // CREATURE_H_INCLUDED
