//CH-230-B
//a11_p4.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include<string>
#include "Creature.h"
//Including header file

using namespace std;

int main()
{ 
    cout << "Creating an Creature.\n";
    Creature c;
    c.run();

    cout << "\nCreating a Wizard.\n";
    Wizard w;
    w.run();
    w.hover();
    cout<<"\nCreating another Wizard.\n";
    Wizard instance1;
    instance1.run();
    instance1.hover();
    //Creating another wizard and calling the methods
    cout<<"\nCreating a Witch.\n";
    Witch instance2;
    instance2.run();
    instance2.magic();
    //Creating a new Creature Witch and calling the methods
    cout<<"\nCreating a Programmer.\n";
    Programmers instance3;
    instance3.run();
    instance3.hack();
    //Creating a new Creature Programmers and calling the methods
    cout<<endl;

    return 0;
} 