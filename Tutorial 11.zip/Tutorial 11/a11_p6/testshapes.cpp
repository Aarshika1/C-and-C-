//CH-230-B
//a11_p6.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include "Shapes.h"

using namespace std;
int main(int argc, char** argv) {

  Circle c("first circle", 3, 4, 7);
  RegularPolygon r("TRIANGLE", 1, 1, 3);

  r.printName();
  c.printName();
  cout<<endl;

  Rectangle rec("Rectangle",1,1,1.2,1.3);
  Square sq("Square",4,5.97,6);
  Circle cir("Circle",1,1,7.7);
  //Declaring instances
  double areaR,areaS,areaC,perimeterR,perimeterS,perimeterC;
  areaR = rec.area();
  areaS = sq.area();
  areaC = cir.area();
  //Calling the area functions and storing the value 
  //in a double
  perimeterR = rec.perimeter();
  perimeterS = sq.perimeter();
  perimeterC = cir.perimeter();
  //Calling the perimeter functions and storing the value in a 
  //double

  rec.printName();
  //Printing the name 
  cout<<"Area of the Rectangle: "<<areaR<<endl;
  cout<<"Perimeter of the Rectangle: "<<perimeterR<<endl;
  //Printing the area and perimeter
  cout<<endl;
  sq.printName();
  //Printing the name
  cout<<"Area of the Square: "<<areaS<<endl;
  cout<<"Perimeter of the Square: "<<perimeterS<<endl;
  //printing the area and perimeter
  cout<<endl;
  cir.printName();
  //Printing the name
  cout<<"Area of the Circle: "<<areaC<<endl;
  cout<<"Perimeter of the Circle: "<<perimeterC<<endl;
  //Printing the area and perimeter
  cout<<endl;


}