//CH-230-B
//a11_p6.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
/* 
	Classic shape examples: an inheritance tree in a geometric context
*/
#ifndef __SHAPES_H
#define __SHAPES_H
#include <string>

class Shape {			// base class
	private:   				// private access modifier: could also be protected
		std::string name;   // every shape will have a name
	public:
        void setS(std::string);
        std::string getS();
		Shape(const std::string&);  // builds a shape with a name
		Shape();					// empty shape
		Shape(const Shape&);		// copy constructor
		void printName() const ;  	// prints the name  
};

class CenteredShape : public Shape {  // inherits from Shape
	private: 
		double x,y;  // the center of the shape
	public:
		void setC(double,double);
        double getCx();
        double getCy();
        CenteredShape(const std::string&, double, double);  // usual three constructors
		CenteredShape();
		CenteredShape(const CenteredShape&);
		void move(double, double);	// moves the shape, i.e. it modifies it center
};

class RegularPolygon : public CenteredShape { // a regular polygon is a centered_shape with a number of edges
	private: 
		int EdgesNumber;
	public:
        void setR(int);
        int getR();
		RegularPolygon(const std::string&, double, double, int);
		RegularPolygon();
		RegularPolygon(const RegularPolygon&);
};

class Circle : public CenteredShape {  // a Circle is a shape with a center and a radius
	private:
		double Radius;
	public:
        void setCir(double);
        double getCir();
        double perimeter();
        double area();
		Circle(const std::string&, double, double, double);
		Circle();
		Circle(const Circle&);
};

class Rectangle : public RegularPolygon {
    private:
        double height;
        double width;
        //Declaring the attributes
    public:
        void setRec(double,double);
        //Setter method
        double getRech();
        double getrecw();
        //Getter method
        double perimeter();
        double area();
        //Functions to calculate area and perimeter
        Rectangle(const std::string&,double,double,double,double);
        Rectangle();
        Rectangle(const Rectangle&);
        //Constructors
};
//Making a new class by inheritance from the Regularpolygon

class Square : public Rectangle {
    private:
        double side;
        //Declaring an attribute
    public:
        void setSq(double);
        //Setter method
        double getSq();
        //Getter method
        Square(const std::string&,double,double,double);
        Square();
        Square(const Square&);
        //Constructors
};
//Making a new class by inheritance from the Rectangle
    
#endif