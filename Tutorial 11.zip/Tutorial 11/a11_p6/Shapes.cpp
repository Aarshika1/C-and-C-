//CH-230-B
//a11_p6.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
// please refer to shapes.h for methods documentation

#include <iostream>
#include "Shapes.h"

using namespace std; 

Shape::Shape(const string& n) : name(n) {
}

void Shape::printName() const {
	cout << name << endl;
}

CenteredShape::CenteredShape(const string& n, double nx, double ny): Shape(n) {
	x = nx;
	y = ny;
}

RegularPolygon::RegularPolygon(const string& n, double nx, double ny, int nl) :
	CenteredShape(n,nx,ny) 
{
	EdgesNumber = nl;
}

Circle::Circle(const string& n, double nx, double ny, double r) : 
  CenteredShape(n,nx,ny) 
{
	Radius = r;
}
Rectangle::Rectangle(const string& n,double nx, double ny,double nwidth, double nheight) :
    RegularPolygon(n,nx,ny,2)
{
    height = nheight;
    width = nwidth;

}
//Parametric constructor definiton for the rectangle
Square :: Square(const string& n,double nx, double ny, double nside) :
    Rectangle(n,nx,ny,nside,nside)
{
    side = nside;

}
//Parametric constructor definition for the square
Shape::Shape()
{
    name = "Default";
}
//Default constructor for the class Shape
CenteredShape::CenteredShape()
{
    x = 0.0;
    y = 0.0;
}
//Default constructor for the class CenteredShape
RegularPolygon::RegularPolygon()
{
    EdgesNumber = 0;
}
//Default constructor for the class RegularPolygon
Circle::Circle()
{
    Radius = 0.0;
}
//Default constructor for the class Circle
Rectangle::Rectangle()
{
    height = 0.0;
    width = 0.0;
}
//Default constructor for the class Rectangle
Square::Square()
{
    side = 0.0;
}
//Default constructor for the class Square
void Shape::setS(string n)
{
    name = n;
}
//Setter for the class Shape
void CenteredShape::setC(double n1, double n2)
{
    x = n1;
    y = n2;
}
//Setter for the class CenteredShape
void RegularPolygon::setR(int n)
{
    EdgesNumber = n;
}
//Setter for the class RegularPolygon
void Circle::setCir(double n)
{
    Radius = n;
}
//Setter for the class Circle
void Rectangle::setRec(double n1,double n2)
{
    height = n1;
    width = n2;
}
//Setter for the class Rectangle
void Square::setSq(double n)
{
    side = n;
}
//Setter for the class Square
string Shape::getS()
{
    return name;
}
//Getter for the class Shape
double CenteredShape::getCx()
{
    return x;
}
double CenteredShape::getCy()
{
    return y;
}
//Getter for the class CenteredShape
int RegularPolygon::getR()
{
    return EdgesNumber;
}
//Getter for the class RegularPolygon
double Circle::getCir()
{
    return Radius;
}
//Getter for the class Circle
double Rectangle::getRech()
{
    return height;
}
double Rectangle::getrecw()
{
    return width;
}
//Getter for the class Rectangle
double Square::getSq()
{
    return side;
}
//Getter for the class Square
Shape::Shape(const Shape &c)
{
    name = c.name;
}
//Copy constructor for the class Shape
CenteredShape::CenteredShape(const CenteredShape &c)
{
    x = c.x;
    y = c.y;
}
//Copy constructor for the class CenteredShape
RegularPolygon::RegularPolygon(const RegularPolygon &c)
{
    EdgesNumber = c.EdgesNumber;
}
//Copy constructor for the class RegularPolygon
Circle::Circle(const Circle &c)
{
    Radius = c.Radius;
}
//Copy constructor for the class Circle
Rectangle::Rectangle(const Rectangle &c)
{
    height = c.height;
    width = c.width;

}
//Copy constructor for the class Rectangle
Square::Square(const Square &c)
{
    side = c.side;
}
//Copy constructor for the class Squares
double Circle::perimeter()
{
    double p;
    p = ((2 * 22 *Radius)/7);
    return p;
}
double Circle::area()
{
    double a;
    a = ((22*Radius*Radius)/7);
    return a;
}
//Methods to compute area and perimeter of Circle
double Rectangle::perimeter()
{
    double p;
    p = 2*(height + width);
    return p;
}
double Rectangle::area()
{
    double a;
    a = (height * width);
    return a;
}
//Methods to compute area and perimeter of Rectangle
//Same will be used by Square due to inheritance