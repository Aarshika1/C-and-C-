//CH-230-B
//a11_p2.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include "Person.h"
//Including the header file
using namespace std;
void Person::setName(string n)
{
    Name = n;
}
//Calling the function to set name.
//It takes a string and returns nothing
void Person::setHeight(float h)
{
    Height = h;
}
//Calling the function to set height.
//It takes a float and returns nothing
void Person::setAge(int a)
{
    Age = a;
}
//Calling the function to set age.
//It takes an integer and returns nothing
void Person::setCountry(string c)
{
    Country = c;
}
//Calling the function to set country.
//It takes a string and returns nothing
string Person::getName()
{
    return Name;
}
//Calling the function to get name.
//It takes nothing and returns a string
float Person::getHeight()
{
    return Height;
}
//Calling the function to get height.
//It takes nothing and returns a float
int Person::getAge()
{
    return Age;
}
//Calling the function to get age.
//It takes nothing and returns an integer
string Person::getCountry()
{
    return Country;
}
//Calling the function to get country.
//It takes nothing and returns a string
Person::Person()
{
    Name = "0";
    Height = 0;
    Age = 0;
    Country = "0";

}
//Default Constructor sets all the attributes to 0
Person::Person(string namepar,float heightpar,int agepar,string countrypar)
{
    Name = namepar;
    Height = heightpar;
    Age = agepar;
    Country = countrypar;
}
//Parametric Constructor to set the attributes
Person::Person(const Person &p)
{
    Name = p.Name;
    Height = p.Height;
    Age = p.Age;
    Country = p.Country;
}
//Copy constructor
void Person::print()
{
    cout<<"Name of the person: "<<Name<<endl;
    cout<<"Height of the person: "<<Height<<endl;
    cout<<"Age of the person: "<<Age<<endl;
    cout<<"Country of the person: "<<Country<<endl;
    cout<<endl;
}
//Print functions for the constructors