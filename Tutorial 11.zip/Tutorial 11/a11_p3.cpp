//CH-230-B
//a11_p3.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include<string>

using namespace std;

class Creature {
	public:
		Creature();  
		void run() const;

	protected:
		int distance;
};

Creature::Creature(): distance(10)
{}    

void Creature::run() const
{ 
    cout << "running " << distance << " meters!\n";
}  

class Wizard : public Creature {
	public:
		Wizard();
		void hover() const;

	private:
		int distFactor;
};

Wizard::Wizard() : distFactor(3)
{}  

void Wizard::hover() const
{
    cout << "hovering " << (distFactor * distance) << " meters!\n";
}

class Witch : public Creature {
    public:
        Witch();
        void magic() const;
    private:
        int flying;
};
//Creating a new class Witch by inheritance from
//Creature
Witch::Witch():flying(6)
{}
//Setting the value of the attricute

void Witch::magic() const
{ 
    cout<<"flying "<<(flying*distance)<<" meters!\n";

}
//Defining the method

class Programmers : public Creature {
    public:
        Programmers();
        void hack() const;
    private:
        string hacking;
};
//Making a class by inheritance from the Creature
Programmers::Programmers():hacking("CampusNet")
{}
//Setting the value of the attribute
void Programmers::hack() const
{
    cout<<"hacking "<<hacking<<";)\n";
}
//Defining the method
int main()
{ 
    cout << "Creating an Creature.\n";
    Creature c;
    c.run();

    cout << "\nCreating a Wizard.\n";
    Wizard w;
    w.run();
    w.hover();
    cout<<"\nCreating another Wizard.\n";
    Wizard instance1;
    instance1.run();
    instance1.hover();
    //Creating another wizard and calling the methods
    cout<<"\nCreating a Witch.\n";
    Witch instance2;
    instance2.run();
    instance2.magic();
    //Creating a Witch and calling the methods
    cout<<"\nCreating a Programmer.\n";
    Programmers instance3;
    instance3.run();
    instance3.hack();
    //Creating a Programmer and calling the methods
    cout<<endl;

    return 0;
} 