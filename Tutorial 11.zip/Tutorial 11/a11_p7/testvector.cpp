//CH-230-B
//a11_p7.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<cmath>
#include "Vector.h"
using namespace std;
int main()
{
    Vector v1(4);
    v1.set(0,0);
    v1.set(1,10);
    v1.set(2,20);
    v1.set(3,30);
    //Making instance using parametric constructor
    Vector v2(v1);
    //Making instance using copy constructor
    Vector v3;
    v3.set(0,40);
    v3.set(1,50);
    v3.set(2,60);
    //Making instance using copy constructor
    double norm2 = v1.norm();
    //Calculating the norm of v1 and storing the value in
    //a double
    cout<<"Norm : "<<norm2<<endl;
    //Printing the norm of v1
    cout<<"Addition: ";
    (v1.add(v3)).print();
    //Calculating the sum of v1 and v3 and printing it
    cout<<"Difference: ";
    (v1.difference(v3)).print();
    //Calculating the difference of v1 and v3 and printing
    cout<<"Scalar product: ";
    (v1.scalar(v3)).print();
    //Calculating the scalar product of v1 and v3 and
    //printing it

    return 0;

}