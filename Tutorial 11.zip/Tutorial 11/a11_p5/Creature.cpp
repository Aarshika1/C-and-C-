//CH-230-B
//a11_p5.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<string>
#include "Creature.h"
//Including the header file
using namespace std;
Creature::Creature(): distance(10)
{}    

void Creature::run() const
{ 
    cout << "running " << distance << " meters!\n";
}  

Wizard::Wizard() : distFactor(3)
{}  

void Wizard::hover() const
{
    cout << "hovering " << (distFactor * distance) << " meters!\n";
}

Witch::Witch():flying(6)
{}
//Setting value to an attribute

void Witch::magic() const
{ 
    cout<<"flying "<<(flying*distance)<<" meters!\n";

}
//Declaring a method

Programmers::Programmers():hacking("CampusNet")
{}
//Setting value to an attribute
void Programmers::hack() const
{
    cout<<"hacking "<<hacking<<";)\n";
}
//Declaring a method