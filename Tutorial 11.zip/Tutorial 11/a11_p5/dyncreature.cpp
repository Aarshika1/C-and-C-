//CH-230-B
//a11_p5.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include<string>
#include "Creature.h"
//Including the header file

using namespace std;

int main()
{ 
    string input;
    while(input != "quit")
    //Until the input is not quit
    {
        cout<<"Please enter your creature: ";
        cin>>input;
        //Taking input from the keyboard
        
        if(input == "wizard")
        {
            Wizard *instance1;
            instance1 = new Wizard;
            cout<<"Creating a Wizard.\n";
            instance1->run();
            instance1->hover();
            delete instance1;

        }
        //if the input is wizard, then an instance 
        //of wizard  is created dynamically the methods are called
        //and the memory is released at the end
        else if(input == "object1")
        {
            Witch *instance2;
            instance2 = new Witch;
            cout<<"Creating a Witch.\n";
            instance2->run();
            instance2->magic();
            delete instance2;
        }
        //if the input is object1, then an instance 
        //of witch is created dynamically the methods are called
        //and the memory is released at the end
        else if(input == "object2")
        {
            Programmers *instance3;
            instance3 = new Programmers;
            cout<<"Creating a Programmer.\n";
            instance3->run();
            instance3->hack();
            delete instance3;
        }
        else
        {
        }
        
        //if the input is object2, then an instance 
        //of programmers is created dynamically the methods are called
        //and the memory is released at the end
    }

    return 0;
} 