/*
   CH-230-B
   a4_p2.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<string.h>
/*Using string library to use strlen function*/
int main()
{
    char string[50];
    fgets(string,sizeof(string),stdin);
    /*Reading the input from keyboards*/
    int i;
    for(i=0;i<strlen(string)-1;i++)
    {
        if(i%2==0)
        {
            printf("%c\n",string[i]);
        }
        else
        {
             printf(" %c\n",string[i]);
        }

        }
        /*Printing the element by checking the odd or
        even character*/

    return 0;
}
h
