/*
   CH-230-B
   a4_p6.
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<stdlib.h>
void greatest_value(int arr[]);
/*Declaring a function*/
int n;
int main(){
printf("Enter an integer:");
scanf("%d",&n);
/*Reading an integer*/
int *array;
array= (int*) malloc (sizeof(int) * n);
/*Allocating memory*/
if ( array == NULL )
    exit (1) ;
int i;
for (i=0;i<n;i++)
{
    printf("Enter the first element:");
    scanf ("%d",&array[i]);
}
/*Taking in values for all the elements of array*/
greatest_value(array);
/*Calling the function*/
free(array);
/*free the memory*/
return 0;
}
void greatest_value(int *array)

{
    int c;
    int h_array=array[0],h_array2=array[0];
    for (c=0;c<n;c++)
    {
        if (array[c]>h_array)
        {
            h_array2 = h_array;
            h_array = array[c];

        }
        if (array[c]>h_array2 && array[c] < h_array)
        {
            h_array2 = array[c];
        }



    }
        printf("The greatest value is %d\n",h_array);
        printf("The second greatest value is %d",h_array2);


}
/*The above function takes in an array and first considers
the first element to be the greatest value and then compares
it with another element of the the array and if the second
element is greater than the first then the second element
is treated as the greatest value and the variable
h_array2 is given the value of the first element*/
