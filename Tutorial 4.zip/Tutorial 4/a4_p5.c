/*
   CH-230-B
   a4_p5.
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<string.h>
int count_consonants(char *str);
int main()
{
    char string[100];
    int conso;

    while(1)
    {
    fgets(string,sizeof(string),stdin);
    if(strcmp(string,"\n")== 0)
            {
                break;
            }
    conso=count_consonants(string);
    /*Referring the string to the pointer in the
    declared function*/
    printf("Number of consonants=%d\n",conso);
    }
    return 0;
}

int count_consonants(char *str)
{
    int i;
    int consonants=0;
    for (i=0;*str!='\n';i++)
    {
        if((*str>=65 && *str<= 90)||(*str >=97 && *str<=122))
        if((*str!='A'&& *str!='E' && *str!='I' && *str!='O' && *str!='U')
           && (*str!='a' && *str!='e' && *str!='i' && *str!='o' && *str!='u'))
        {
            consonants=consonants+1;

        }
        str++;
        /*Using pointer arithmetic*/

    }
    return consonants;
}
/*Changing the input for the above value to be a pointer*/
