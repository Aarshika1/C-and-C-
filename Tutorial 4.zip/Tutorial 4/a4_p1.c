/*
   CH-230-B
   a4_p1.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<math.h>
int main()
{
    float x,upper_limit,lower_limit,increment;
    double pi=3.14159265358979323846;
    scanf("%f",&lower_limit);
    scanf("%f",&upper_limit);
    scanf("%f",&increment);
    /*Reading the input from the keyboard*/
    for(x=lower_limit;x<=upper_limit;x=x+increment)
    {
        printf("%f %f %f\n",x,x*x*pi,2*x*pi);
        /*Printing the output using the for loop*/
    }
return 0;
}
