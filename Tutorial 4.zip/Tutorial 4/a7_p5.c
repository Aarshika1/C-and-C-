/*
   CH-230-B
   a7_p5.
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<stdlib.h>
/*Including the libraries*/
int compare1(const void *a, const void *b)
{
    const int *ia = (const int *)a;
    const int *ib = (const int *)b;
    if(*ia < *ib)
    return -1;
    else if(* ia> *ib)
    return 1;
    else
    return 0;
}
/*The above function-
1) Takes in two constant generic pointers
2) Uses int to typecast the pointers
3) Compares the value of the inetgers and returns 
an integer accordingly
4) It is used to ascendingly order the integers*/

int compare2(const void *a, const void *b)
{
    const int *ia = (const int *)a;
    const int *ib = (const int *)b;
    if(*ia < *ib)
    return 1;
    else if(* ia> *ib)
    return -1;
    else
    return 0;
}
/*The above function-
1) Takes in two constant generic pointers
2) Uses int to typecast the pointers
3) Compares the value of the inetgers and returns 
an integer accordingly
4) It is used to descendingly order the integers*/

int main()
{
    int n,i;
    scanf("%d",&n);
    int array[n];
    /*Scanning the size of the array*/
    for(i=0;i<n;i++)
    {
        scanf("%d",&array[i]);
    }
    /*Scanning the elements of the array*/
    char c;
    while(1)
    /*While loop to take multiples input*/
    {
        scanf("%c",&c);
        if(c=='a')
        {
            qsort(array,n,sizeof(array[0]),compare1);
            /*Using qsort for arranging the inetgers in ascending
            order*/
            for(i=0;i<n;i++)
            {
                printf("%d ",array[i]);
            }
            /*Printing the arranged array*/
            printf("\n");

        }
        if(c=='d')
        {
             qsort(array,n,sizeof(array[0]),compare2);
             /*Using qsort for arranging the inetegers in descending
             order*/
            for(i=0;i<n;i++)
            {
                printf("%d ",array[i]);
            }
            /*Printing the arranged array*/
            printf("\n");
        }
        if(c=='e')
        {
            exit(1);
        }
        /*Exiting the program*/
    }
return 0;
}