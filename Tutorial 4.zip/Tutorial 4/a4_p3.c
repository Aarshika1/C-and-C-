/*
   CH-230-B
   a4_p3.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<math.h>
/*Including library to calculate power*/
float geometric_mean(float arr[], int number);
float highest_array(float arr[], int number);
float lowest_array(float arr[], int number);
float sum_array(float arr[], int number);
/*Declaring functions*/
int main()
{
    float array_1[15],geom_mean,high_array,low_array,sum;
    int i;
    char c;
    for(i=0;i<15;i++)
    {
        printf("Enter a float %d:",(i+1));
        scanf("%f",&array_1[i]);
        if(array_1[i] < 0)
        {
            i--;
            break;
        }
    }
    /*Reading the values of the elements of the
    declared array*/
    printf("Enter a character:");
    getchar();
    /*Reading a character*/
    scanf("%c",&c);
    switch (c){
        case 'm':
            geom_mean=geometric_mean(array_1,i);
            printf("Geometric Mean=%f",geom_mean);
            break;
            /*Switch case to calculate mean*/

        case 'h':
            high_array=highest_array(array_1,i);
            printf("Highest float in the given float=%f",high_array);
            break;
            /*Switch case to check the highest value
            among all the elements*/

        case 'l':
            low_array=lowest_array(array_1,i);
            printf("Lowest float in the given float=%f",low_array);
            break;
            /*Switch case to check the lowest value
            among all the elements*/

        case 's':
            sum=sum_array(array_1,i);
            printf("Sum of all the elements of the given float=%f",sum);
            break;
            /*Switch case to compute the sum of all the elements
            of the array*/
            }
    return 0;
}
float geometric_mean(float arr[], int number)
{
    float gmean;
    float product=1;
    int y;
    for(y=0;y<number;y++)
    {
        product=product*arr[y];
    }
    gmean= pow(product, (float)1 / number);
    return gmean;
    }
/*The above function takes in a float array value and an integer
and first calculates the product of the entered value of the array
continuously and then using 'pow' function raises the product
to the power of the size of the array to calculate the mean*/

float highest_array(float arr[],int number)
{
    float h_array;
    int c;
    h_array=arr[0];
    for (c=0;c<number;c++)
    {
        if (arr[c]>h_array)
        {
            h_array=arr[c];
        }

    }
    return h_array;
}
/*The above function takes in the float values of the array and an integer
and a float h_array is declared and is considered as the highest value
at beginning. Then the different values of the array is equated to the
declared h_array and if the value is greater than h_array then the
value of h_array is changed to that of the new element of the
array*/
float lowest_array(float arr[], int number)
{
    float l_array;
    int d;
    l_array=arr[0];
    for(d=0;d<number;d++)
    {
        if(arr[d]<l_array)
        {
            l_array=arr[d];
        }
    }

    return l_array;
}
/*The above function works in the similar manner as the highest_array
function does. The only difference is that the different elements are
checked for the less than inequality with the initially declared
lowest value*/
float sum_array(float arr[], int number)
{
    float s_array=0;
    int e;
    for (e=0;e<number;e++)
    {
        s_array=s_array+arr[e];
    }

    return s_array;

}
/*The above function takes in the float array value and an integer
and increments the s_array by the other value of the element of the
array*/


