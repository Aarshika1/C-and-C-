/*
   CH-230-B
   a4_p7.
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
void table(int arr[30][30],int k);
void diagonal(int arr[30][30],int k);
/*Declaring functions*/
int main()
{
    int array [30][30];
    int k;
    scanf("%d",&k);
    /*Reading the number of rows and columns*/
    int a,b;
    for(a=0;a<k;a++){
        for(b=0;b<k;b++){
            scanf("%d",&array[a][b]);
    /*Scanning all the elements for the square table
    by a for loop*/
    }

    }
    table(array,k);
    diagonal(array, k);
    /*Calling the functions*/
    return 0;


}
void table(int array[30][30],int k)
{
    int a,b;
    printf("The entered matrix is:\n");
    for(a=0;a<k;a++)
    {
        for(b=0;b<k;b++){
        printf("%d ",array[a][b]);
    }
    printf("\n");
    }
}
/*The above function takes in a multidimensinal array and
the size of the rows and columns and prints the table by
for loop*/
void diagonal(int arr[30][30],int k)
{
    int a,b,diagonal_1;
    printf("Under the main diagonal:\n");
    for(a=0;a<k;a++)
    {
        for(b=0;b<k;b++)
        {
            if(a>b)
            {
                diagonal_1=arr[a][b];
                printf("%d ",diagonal_1);

            }

        }

    }
    printf("\n");
}
/*The above function takes in a multidimensional array and
the size of the rows and columns. It determines the values under
the main diagonal by checking if the row number is greater
than the column number*/

