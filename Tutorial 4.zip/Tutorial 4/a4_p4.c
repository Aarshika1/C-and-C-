/*
   CH-230-B
   a4_p4.
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<string.h>
int count_consonants(char str[]);
/*Declaring a function*/
int main()
{
    char string[100];
    int conso;

    while(1)
    {
    fgets(string,sizeof(string),stdin);
    if (strcmp(string,"\n")== 0)
        {
            break;
        }
    /*Reading the string from keyboard and if the
    entered program is empty then the above if condition
    would break the loop*/
    conso=count_consonants(string);
    printf("Number of consonants=%d\n",conso);
    /*calling the function*/
    }

    return 0;
}

int count_consonants(char str[])
{
    int i;
    int consonants=0;
    for (i=0;str[i]!='\n';i++)
    {
        if((str[i]>=65 && str[i]<= 90)||(str[i]>=97 && str[i]<=122))
        if(str[i]!='A'&& str[i]!='E' && str[i]!='I' && str[i]!='O' && str[i]!='U'
           && str[i]!='a' && str[i]!='e' && str[i]!='i' && str[i]!='o' && str[i]!='u')
        {
            consonants=consonants+1;

        }

    }
    return consonants;
}
/*The above function takes in a string and checks if the string
has all the characters as alphabets and checks for the vowels.
If a character is not any vowel than it increases the consonants
count by 1*/
