/*
   CH-230-B
   a4_p11.
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
/*Including the libraries*/

int count_insensitive(char *str, char c);
/*Declaring the function*/

int main()
{
	char *str,*str2,ch;
	int a;

	printf("Enter a character=");
	ch=getchar();
	getchar();
	/*Reading a character and adding getchar for newline*/

	str=(char *)malloc(sizeof (char) * 50);
	/*Allocating memory*/
	if(str == NULL)
    {
        exit(1);
    }
    /*If the string is empty then no memory is
    allocated*/
    printf("Enter a string=");
    fgets(str,50,stdin);
    /*Reading the string from the keyboard*/

    a=strlen(str);
    /*The size of first array*/


	str2=(char *)malloc(sizeof (char) * a);
	/*Allocating the memory to second array*/
	if(str == NULL)
    {
        exit(1);
    }
    /*No memory allocated if the string is empty*/

  	strcpy(str2,str);
  	/*Copying the first string to the second string*/

	free(str);
	/*Freeing the memory*/
	printf("The character '%c' occurs %d times.\n",ch,count_insensitive(str2,ch));
	/*Calling the function*/

	free(str2);
	/*Freeing the memory*/
	return 0;
}

int count_insensitive(char *str, char c)
{
	int freq=0;
	char ch=c;
	if(ch>=65&& ch<=90)
	{
		ch=tolower(ch);
	}
	else if(ch>=97 && ch<=122)
	{
		ch=toupper(ch);
	}
	else
	{
		ch=ch;
	}
    while(*str)
    {
    	if(*str==c || *str==ch)
    	{
    		freq++;
		}
		str++;
	}
	return freq;
}
/*The above function takes in a string and a character and converts
the character into upper and lower case and counts the occurrence
of the character into the given string*/
