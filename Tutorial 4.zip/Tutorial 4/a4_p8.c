/*
   CH-230-B
   a4_p8.
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
void table(int arr[30][30],int k);
void diagonal(int arr[30][30],int k);
int main()
{
    int array [30][30];
    int k;
    scanf("%d",&k);
    int a,b;
    for(a=0;a<k;a++){
        for(b=0;b<k;b++){
            scanf("%d",&array[a][b]);
    }

    }
    table(array,k);
    diagonal(array, k);
    return 0;


}
void table(int array[30][30],int k)
{
    int a,b;
    printf("The entered matrix is:\n");
    for(a=0;a<k;a++)
    {
        for(b=0;b<k;b++){
        printf("%d ",array[a][b]);
    }
    printf("\n");
    }
}
void diagonal(int arr[30][30],int k)
{
    int a,b,diagonal_1;
    printf("Under the secondary diagonal:\n");
    for(a=0;a<k;a++)
    {
        for(b=0;b<k;b++)
        {
            if((a+b)>(k-1))
            {
                diagonal_1=arr[a][b];
                printf("%d ",diagonal_1);

            }

        }
    }
     printf("\n");
}
/*The above program is same as the a4_p7.
the only difference that it prints the elements
under the secondary diagonal are printed.
For it the sum of the row number and the
column number is greater than the number of the
row(/column) is used.*/
