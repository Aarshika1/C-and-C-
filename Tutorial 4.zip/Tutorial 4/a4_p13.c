/*
   CH-230-B
   a4_p13.
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<string.h>
#include<ctype.h>
/*Including libraries*/
void uppcase(char *str);
void lowcase(char *str);
/*Declaring functions*/
int main()
{
    char string[90];
    while(1)
    {
        fgets(string,sizeof(string),stdin);
        /*Reading a string from the keyboard*/
        if(strncmp(string,"exit",4)==0)
        {
            break;
        }
        /*The function breaks if exit is entered*/

        uppcase(string);
        lowcase(string);
        /*Calling the functions*/
    }
    return 0;
}
void uppcase(char *str)
{
    int a;
    for(a=0;a<90;a++)
    {
        if(isupper(str[a])==0)
        {
            str[a]=toupper(str[a]);
        }
    }
    printf("uppcase=%s",str);
}
/*The above function takes in a character(pointer) and uses
isupper function to compare and toupper function to convert
the lower case characters to upper case characters*/
void lowcase(char *str)
{
    int b;
    for(b=0;b<90;b++)
    {
        if(islower(str[b])==0)
        {
            str[b]=tolower(str[b]);
        }
    }
    printf("lowcase=%s",str);
}
/*The above function works in the same manner as the uppcase function.
It uses islower function to compare and tolower function
to convert upper case characters to lower case characters*/
