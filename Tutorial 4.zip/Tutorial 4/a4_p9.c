/*
   CH-230-B
   a4_p9.
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<stdlib.h>
int prodminmax(int arr[], int n);
/*Declaring a function*/
int n;
int main()
{
    printf("Enter an integer for the size of array:");
    scanf("%d",&n);
    /*Reading the size of the array*/
    int counts,arr[n];
    for(counts=0;counts<n;counts++)
    {
        printf("Enter the %d th element of the array ",(counts+1));
        scanf("%d",&arr[counts]);
    }
    /*Reading the elements for the array*/
    int *memory;
    memory= (int*) malloc (sizeof(int) * n);
    /*Allocating memory*/
    printf("The product of the max and the min element = %d",prodminmax(arr,n));
    /*Calling the function and printing its value*/
    free(memory);
    /*Making the memory free*/
    return 0;

}
int prodminmax(int arr[], int n)
{
    int max,min,counts1,counts2,product_minmax;
    max=arr[0];
    for(counts1=0;counts1<n;counts1++)
    {
        if(arr[counts1]>max)
        {
            max = arr[counts1];
        }
    }
    min=arr[0];
    for(counts2=0;counts2<n;counts2++)
    {
        if(arr[counts2]<min)
        {
            min = arr[counts2];
        }
    }
    product_minmax = max*min;
    return product_minmax;

}
/*The above function takes in the array and an integer.
Calculates the greatest element and the lowest element,
calculates the product and returns its value*/

