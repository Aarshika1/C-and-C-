/*
   CH-230-B
   a4_p12.
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
/*Including the libraries*/
void replaceAll(char *str, char c, char e);
/*Declaring the function*/
int main()
{
    char str[80],char1,char2;

    while(1){
    printf("Enter a string: ");
    fgets(str,sizeof(str),stdin);
    /*Reading a string from the keyboard*/
    if(strncmp(str,"stop",4)==0)
    {
        break;
    }
    /*Comparing the string to stop and breaking it
    if the entered string is stop*/
    printf("Enter the character to be replaced: ");
    scanf("%c",&char1);
    getchar();
    printf("Enter the replacement character: ");
    scanf("%c",&char2);
    getchar();
    /*Reading the character to be replaced and the
    replaced character*/
    printf("The old string is: %s",str);
    replaceAll(str,char1,char2);
    printf("The new string is: %s",str);
    /*Printing the strings*/

    }
    return 0;

}
void replaceAll(char *str, char c, char e)
{
    int i;
    for(i=0;i<80 && i!='\n';i++)
    {
        if(str[i]==c)
        {
            (str[i]=e);
        }
    }
}
/*The above function takes in a string(pointer), and two
characters and replaces the first character with the second character*/
