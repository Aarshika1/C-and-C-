/*
   CH-230-B
   a4_p10.
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<math.h>
void proddivpowinv(float a, float b, float *prod, float *div,float *pwr, float *invb);
/*Declaring a function*/
int main()
{
    float prod,div,pwr,invb;
    float a=1;
    float b=1;
    proddivpowinv(a,b,&prod,&div,&pwr,&invb);
    /*Calling the function*/

    printf("Product of the floats = %f\n",prod);
    printf("Division of the floats = %f\n",div);
    printf("Power of the first float to the second float = %f\n",pwr);
    printf("Inverse of the second float = %f",invb);
    /*Printing the values of the variables stored in the pointers*/
    return 0;
}

void proddivpowinv(float a,float b,float *prod, float *div,float *pwr, float *invb)
{
    printf("Enter the first float: ");
    scanf("%f",&a);
    printf("Enter the second float: ");
    scanf("%f",&b);
    *prod = a*b;
    *div = a/b;
    *pwr = pow(a,b);
    *invb = (1/b);

}
/*The above function takes in float values of 2 floats and 4 pointers
and uses the pointers to compute the arithmetic calculations and
it returns nothing*/
