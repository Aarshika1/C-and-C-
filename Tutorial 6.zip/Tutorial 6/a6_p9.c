/*
   CH-230-B
   a6_p9.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<stdlib.h>
/*Including libraries*/
typedef struct list
{
    int info;
    struct list *link;
}node;
/*Declaring a structure with an integer info and a pointer
link of the same type and using typedef to name the
structure as node for ease of application*/
node *start = NULL;
/*Declaring a pointer of type struct list, using node and
initializing to NULL*/
void insertElel()
{
    node *i,*j;
    i=(node*)malloc(sizeof(node));
    if(i==NULL)
    {
        exit(1);
    }
    scanf("%d",&i->info);
    i->link=NULL;
        if(start==NULL)
        {
            start=i;
        }
        else
        {
            j=start;
            while(j->link!=NULL)
                j=j->link;
            j->link=i;
        }
}
/*The above function
1) Declares two pinter and allocates memory to i
2) Scans the value of the pointer i
3) Initializes the pointer link of the pointer i
to NULL, hence attaching it at the end of the linked
list
4) if the list is empty, then the new element is attached
to start,as there is no other element.
5) otherwise other pointer j is initialized to start
and while loop is used to attach the other elements in
front of the newly added element, making it the last element
of the linked list*/

void insertEleb()
{
    node *k;
    k=(node*)malloc(sizeof(node));
    if(k==NULL)
    {
        exit(1);
    }
    scanf("%d",&k->info);
    k->link=start;
    start=k;
}
/*The above function
1) Declares a pointer of type struct list
2) Allocates memory to k
3) Scans the value of the info of k
4) Connects k using its pointer to the start variable
making it the first element in the linked list*/
void insetEles()
{
    node *s,*t;
    int data,pos,i,j;
    scanf("%d",&pos);
    scanf("%d",&data);
    s=(node*)malloc(sizeof(node));
    if(s==NULL)
    {
        exit(1);
    }
    s->info=data;
    s->link=NULL;
    int count = 0;
    node* current = start;
    while (current != NULL)
    {
        count++;
        current = current->link;
    }
    j=count;
    if(pos==0)
    {
        s->link=start;
        start=s;
    }
    if(pos<0||pos>j)
        {
            printf("Invalid position!\n");
        }
    t=start;
    if(pos>=0&&pos<=j)
    {for(i=0;i<pos-2;i++)
    {
            t=t->link;
    }
    s->link=t->link;
    t->link=s;
    }

}
/*The above function
1) Declares two pointers of type struct list
2) Allocates memory to the pointer s
3) It counts the number of elements in the linked list
and stores it in integer j.
3) If the scanned pos is 0 then it,
It stores the value of the integer data, which
is scanned from the keyboard in the info of s
4) It initializes start to s
5) If the position entered is either negative or
greater than the number of elements then the message
is printed
6) Using for loop the pointer t is incremented till
it is less than pos-2
7) The pointer of s is equated to the pointer of t
8) And the value of s is stored in the pointer of t.*/
void reverseL()
{
    node *pre,*current,*next;
    current=start;
    pre=NULL;
    while(current!=NULL)
    {
        next=current->link;
        current->link=pre;
        pre=current;
        current=next;
    }
    start=pre;
}
/*In the above function
1) Three pointers of type struct int are declared
2) The pointer current is initialized to start and
pre is initialized to NULL.
3) Using the while loop, the value of the next element
is stored in the previous element, till current becomes
NULL, reversing the linked list.*/
void deleteEle()
{
    node *r;
    if(start==NULL)
    {

    }
    else
    {
        r=start;
        start=start->link;
        free(r);
    }

}
/*The above function
1) Declares a pointer r of type struct list
2) If the start value is null, the the list
is empty
3) Otherwise, it initializes r to start
and stores the value of start in the pointer
link of the start
4) It then frees r, hence deleting the specific
element from the linked list*/
void print()
{
    node *p;
        p=start;
        while(p!=NULL)
        {
            printf("%d ",p->info);
            p=p->link;
        }
        printf("\n");
}
/*The above function
1) Declares a pointer p of type struct list
2) If the list is empty, then it prints the message
3) Otherwise, it initializes p to start ans till p is
not null it prints all the value of p by increasing p
using p=p->link. Hence printing the list.*/
void freeEle()
{
    node *f;
    while(start!=NULL)
    {
        f=start->link;
        free(start);
        start=f;
        }
}
/*The above function
1) Declares a pointer
2) Stores the value of the link of start in f
3) Frees the list*/

int main()
{
    while(1)
        /*(1) Using while to read until q is scanned*/
    {
        char c;
        scanf("%c",&c);
    /*(2) Reading character*/
        switch(c)
        {
        case 'a':
            insertElel();
            break;
        case 'b':
            insertEleb();
            break;
        case 'p':
            print();
            break;
        case 'r':
            deleteEle();
            break;
        case 'i':
            insetEles();
            break;
        case 'R':
            reverseL();
            break;
        case 'q':
            freeEle();
            exit(0);
        default:
            printf("Invalid choice\n");
        }
        /*(3) Using switch to call the particular function
        according to the character scanned*/
        getchar();
    }
return 0;
}
