/*
   CH-230-B
   a6_p6.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    unsigned char c;
    /*Declaring unsigned character*/
    int n;
    scanf("%c",&c);
    /*Scanning unsigned character*/
    printf("The decimal representation is: %d\n",c);
    /*Printing the decimal representation by using %d*/
    printf("The binary representation is: ");
    for (n=7;n>=0;n--)
    {
        printf("%d",((c>>n)&1));
    }
    /*Printing the backward binary representation by
    using BITWISE operators.The integer n is used for the
    the for loop.The n is initialized to 7 as the binary
    representation is 8 bits. And the for loops continues in
    the backward direction till it becomes equal to zero.
    The binary representation is printed by right shifting the
    n c times and masking it with 1*/
    printf("\n");
    /*Printing a new line*/
    return 0;

}
