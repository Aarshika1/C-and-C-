#include<stdio.h>
typedef struct list
{
    int value;
    struct list *link;
} node_t;
void print (node_t * head);
int main()
{
    int value,m;
    printf("please enter an integer : ");
    scanf(" %d", &value);
    scanf("%d",&m);
    node_t * head = NULL;
    push(&head, value);
    push(&head, m);
    printf("\n");
    print(head);




}

void print (node_t * head)
{

    while(head!=NULL)
    {
    printf("%d ",head->value);
    head=head->link;
    }

}


void push(node_t ** head_ref, int new_data)
{
    /* 1. allocate node */
    node_t* new_node = (node_t*) malloc(sizeof(node_t));

    /* 2. put in the data  */
    new_node->value  = new_data;

    /* 3. Make next of new node as head */
    new_node->link = (*head_ref);

    /* 4. move the head to point to the new node */
    (*head_ref)    = new_node;
}
