/*
   CH-230-B
   a6_p5.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    unsigned char c;
    /*Declaring unsigned character*/
    int n;
    scanf("%c",&c);
    /*Scanning unsigned character*/
    printf("The decimal representation is: %d\n",c);
    /*Printing the decimal representation by using %d*/
    printf("The backwards binary representation is: ");
    for (n=0;(1<<n)<=c;n++)
    {
        printf("%d",((c>>n)&1));

    }

    /*Printing the backward binary representation by
    using BITWISE operators.The n integer is used in a
    for loop and the condition is set to left shift the
    n by 1 till is it less than equal to the binary of
    the character c. Then the result is calculated by
    right shifting the integer n by c times and masking it
    by 1*/
    printf("\n");
    /*Printing a new line*/
    return 0;

}
