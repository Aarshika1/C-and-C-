/*
   CH-230-B
   a6_p1.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#define MACRO(a,b,data) do{data c;c=a;a=b;b=c;} while(0);
/*Defining MACRO using data type and two variables*/
int main()
{
    int one,two;
    double onef,twof;
    scanf("%d",&one);
    scanf("%d",&two);
    scanf("%lf",&onef);
    scanf("%lf",&twof);
    /*Reading two integers and two floats*/
    MACRO(one,two,int);
    MACRO(onef,twof,double);
    /*Using MACRO to swap the variables*/

    printf("After swapping:\n");
    printf("%d\n%d\n%.6lf\n%.6lf\n",one,two,onef,twof);
    /*Printing after swapping*/
    return 0;
}
