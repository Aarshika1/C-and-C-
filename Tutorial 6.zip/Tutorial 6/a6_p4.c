/*
   CH-230-B
   a6_p4.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
//#define INTERMEDIATE
/*Defining the macro*/
int main()
{
    int dimension,i;
    scanf("%d",&dimension);
    /*Reading the dimension of the vectors*/
    int v[dimension],w[dimension];
    for(i=0;i<dimension;i++)
    {
        scanf("%d",&v[i]);
    }
    /*Reading the values of the first vector*/
    for(i=0;i<dimension;i++)
    {
        scanf("%d",&w[i]);
    }
    /*Reading the values of the second vector*/
    #if defined INTERMEDIATE
    printf("The intermediate product values are:\n");
    for(i=0;i<dimension;i++)
    {
        printf("%d\n",v[i]*w[i]);
    }
    #endif
    /*Using Conditional inclusion to check if the
    macro INTERMEDIATE is defined or not. If it is
    defined, then printing the value of the intermediate
    products which are calculated by using a for loop. If
    the macro is not defined, then doing nothing. Finally
    using endif to close the condition*/
    int pro,sum=0;
    /*Using counter variable sum*/
    for(i=0;i<dimension;i++)
    {
        pro=v[i]*w[i];
        sum=sum+pro;
    }
    /*Calculating the scalar product using counter variable
    and for loop*/

    printf("The scalar product is: %d",sum);
    /*Printing the scalar product*/
    return 0;
}
