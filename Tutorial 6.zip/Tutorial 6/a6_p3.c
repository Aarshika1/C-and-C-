/*
   CH-230-B
   a6_p3.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#define Min1(a,b) (a<b?a:b)
/*The above macro compares the first two
integers and decides the least out of them*/
#define Min2(a,b,c) (Min1(Min1(a,b),c))
/*The above macro compares the least out of the
previous two integers and the third integer and computes
the least of them*/
#define Max1(a,b) (a>b?a:b)
/*The above macro compares the first two integers
and decides the largest out of them*/
#define Max2(a,b,c) (Max1(Max1(a,b),c))
/*The above macro compares the greatest integer
out of the first two integer and the third integer
and finds the greatest integer out of them*/
#define MidRange(a,b,c) ((Min2(a,b,c)+Max2(a,b,c))/2.0)
/*The above macro adds the least and the largest integer
and divides it by 2 to find the midrange value. 2 is written to be
2.0 for the float calculation*/
int main()
{
    int a,b,c;
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);
    /*Reading the integers*/
    printf("The mid-range is: %.6f\n",MidRange(a,b,c));
    /*Printing the midrange value*/
    return 0;

}
