/*
   CH-230-B
   a6_p7.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
void set3bits(unsigned char c,int a, int b, int d);
/*Declaring the function*/
int main()
{
    unsigned char c;
    scanf("%c",&c);
    /*Scanning the unsigned character*/
    int a,b,d;
    scanf("%d\n",&a);
    scanf("%d\n",&b);
    scanf("%d",&d);
    /*Scanning the positions where the bits need
    to be changed to 1*/
    printf("The decimal representation is: %d\n",c);
    set3bits(c,a,b,d);
    /*Calling the function*/
    return 0;
}
void set3bits(unsigned char c,int a, int b, int d)
/*Defining the function*/
{
    int i;
    printf("The binary representation is: ");
    for (i=7;i>=0;i--)
    {
        printf("%d",((c>>i)&1));
    }
    printf("\n");

    c |= 1 << a;
    c |= 1 << b;
    c |= 1 << d;

    printf("After setting the bits: ");
    for(i=7;i>=0;i--)
    {
        printf("%d",((c>>i)&1));
    }
    printf("\n");

}
/*The above function takes in an unsigned character and
three integers(positions). It converts the character into
its binary representation using bitwise operators and the
changes the binary digit of the character c at position
a,b,d using the bitwise operator OR and then prints the
new representation.*/
