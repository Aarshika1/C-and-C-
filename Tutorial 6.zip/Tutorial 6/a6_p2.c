/*
   CH-230-B
   a6_p2.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#define MACRO(x)(x&1)
/*Defining MACRO by taking an integer and using
bitwise operator*/

int main()
{
    unsigned char c;
    /*Declaring unsigned character*/
    scanf("%c",&c);
    /*Reading the character*/
    printf("The decimal representation is %d\n",c);
    int result = MACRO(c);
    /*Calling MACRO and storing the value in an integer*/
    printf("The least significant bit is %d\n",result);
    /*Printing the result*/

    return 0;

}
