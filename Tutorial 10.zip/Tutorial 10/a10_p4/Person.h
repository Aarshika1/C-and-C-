//CH-230-B
//a10_p4.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#ifndef PERSON_H_INCLUDED
#define PERSON_H_INCLUDED
#include<string>
using namespace std;
class Person
{
    private:
    string Name;
    float Height;
    int Age;
    string Country;
    //Declaring Properties
    public:
    void setName(string n);
    void setHeight(float h);
    void setAge(int a);
    void setCountry(string c);
    //Setter for the properties
    string getName();
    float getHeight();
    int getAge();
    string getCountry();
    //Getter for the properties
};
//Declaring a class named Person
#endif // PERSON_H_INCLUDED
