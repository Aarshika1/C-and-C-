//CH-230-B
//a10_p4.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include "Person.h"
//Including the header file
using namespace std;
void Person::setName(string n)
{
    Name = n;
}
//Calling the function to set name.
//It takes a string and returns nothing
void Person::setHeight(float h)
{
    Height = h;
}
//Calling the function to set height.
//It takes a float and returns nothing
void Person::setAge(int a)
{
    Age = a;
}
//Calling the function to set age.
//It takes an integer and returns nothing
void Person::setCountry(string c)
{
    Country = c;
}
//Calling the function to set country.
//It takes a string and returns nothing
string Person::getName()
{
    return Name;
}
//Calling the function to get name.
//It takes nothing and returns a string
float Person::getHeight()
{
    return Height;
}
//Calling the function to get height.
//It takes nothing and returns a float
int Person::getAge()
{
    return Age;
}
//Calling the function to get age.
//It takes nothing and returns an integer
string Person::getCountry()
{
    return Country;
}
//Calling the function to get country.
//It takes nothing and returns a string