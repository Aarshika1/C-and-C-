//CH-230-B
//a10_p4.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include "Person.h"
using namespace std;

int main()
{
    Person P1,P2,P3;
    //Declaring 3 instances
    P1.setName("Aarshika");
    cout<<"Name of the first person: "<<P1.getName()<<endl;
    P1.setHeight(160.56);
    cout<<"The height of the first person is: "<<P1.getHeight()<<endl;
    P1.setAge(19);
    cout<<"The age of the first person is: "<<P1.getAge()<<endl;
    P1.setCountry("India");
    cout<<"The country of origin of the first person is: "<<P1.getCountry()<<endl;
    cout<<endl;
    //Setting and getting attributes for the first instance
    P2.setName("Shramish");
    cout<<"Name of the second person: "<<P2.getName()<<endl;
    P2.setHeight(176.23);
    cout<<"The height of the second person is: "<<P2.getHeight()<<endl;
    P2.setAge(18);
    cout<<"The age of the second person is: "<<P2.getAge()<<endl;
    P2.setCountry("Nepal");
    cout<<"The country of origin of the second person is: "<<P2.getCountry()<<endl;
    cout<<endl;
    //Setting and getting attributes for the second instance0.
    P3.setName("Olta");
    cout<<"Name of the third person: "<<P3.getName()<<endl;
    P3.setHeight(165.24);
    cout<<"The height of the third person is: "<<P3.getHeight()<<endl;
    P3.setAge(20);
    cout<<"The age of the third person is: "<<P3.getAge()<<endl;
    P3.setCountry("Albania");
    cout<<"The country of origin of the third person is: "<<P3.getCountry()<<endl;
    cout<<endl;
    //Setting and getting attributes for the third instance
    return 0;

}