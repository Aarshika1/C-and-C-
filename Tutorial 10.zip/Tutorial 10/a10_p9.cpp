//CH-230-B
//a10_p9.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
