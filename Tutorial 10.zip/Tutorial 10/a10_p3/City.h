//CH-230-B
//a10_p3.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#ifndef CITY_H_INCLUDED
#define CITY_H_INCLUDED
#include<string>
using namespace std;
class City
{
    private:
    string name;
    int population;
    string mayor;
    float area;
    //Declaring properties in the private 

    public:
    void setname(string n);
    void setpop(int p);
    void setmayor(string m);
    void setarea(float a);
    //Setter for the attributes
    string getname();
    int getpop();
    string getmayor();
    float getarea();
    //Getter for the attributes
};



#endif // CITY_H_INCLUDED
