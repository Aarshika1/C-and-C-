//CH-230-B
//a10_p3.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de#
#include<iostream>
#include "City.h"
//Including header file
using namespace std;
int main()
{
    City Bremen;
    City Paris;
    City London;
    //Declaring three instances
    Bremen.setname("Bremen");
    cout<<"Name of the City: "<<Bremen.getname()<<endl;
    Bremen.setpop(681032);
    cout<<"Number of inhabitants: "<<Bremen.getpop()<<endl;
    Bremen.setmayor("Andreas Bovenschulte");
    cout<<"Mayor of the city: "<<Bremen.getmayor()<<endl;
    Bremen.setarea(326.7);
    cout<<"Area of the city: "<<Bremen.getarea()<<endl;
    cout<<endl;
    //Calling setter and getter functions for the first instance
    Paris.setname("Paris");
    cout<<"Name of the City: "<<Paris.getname()<<endl;
    Paris.setpop(2141000);
    cout<<"Number of inhabitants: "<<Paris.getpop()<<endl;
    Paris.setmayor("Anne Hidalgo");
    cout<<"Mayor of the city: "<<Paris.getmayor()<<endl;
    Paris.setarea(105.4);
    cout<<"Area of the city: "<<Paris.getarea()<<endl;
    cout<<endl;
    //Calling setter and getter fucntions for second instance
    London.setname("London");
    cout<<"Name of the City: "<<London.getname()<<endl;
    London.setpop(8900000);
    cout<<"Number of inhabitants: "<<London.getpop()<<endl;
    London.setmayor("Sadiq Khan");
    cout<<"Mayor of the city: "<<London.getmayor()<<endl;
    London.setarea(1572);
    cout<<"Area of the city: "<<London.getarea()<<endl;
    //Calling setter and getter function for third instance
    return 0;

}
