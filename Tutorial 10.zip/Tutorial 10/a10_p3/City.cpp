//CH-230-B
//a10_p3.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include "City.h"
//Including header file
using namespace std;
void City::setname(string n)
{
    name = n;
}
//Defining the setter for the name
//It takes in a string and returns nothing
void City::setpop(int p)
{
    population = p;
}
//Defining the setter for the population
//It takes in an integer and returns nothing
void City::setmayor(string m)
{
    mayor = m;
}
//Defining the setter for the name of the mayor
//It takes in a string and returns nothing
void City::setarea(float a)
{
    area = a;
}
//Defining the setter for the area
//It takes in a float and returns nothing
string City::getname()
{
    return name;
}
//Defining the getter for the name
//It takes in nothing and returns a string
int City::getpop()
{
    return population;
}
//Defining the getter for the number of inhabitants
//It takes in nothing and returns an integer
string City::getmayor()
{
    return mayor;
}
//Defining the getter for the name of mayor
//It takes in nothing and returns a string
float City::getarea()
{
    return area;
}
//Defining the getter for the area
//It takes in nothing and returns a float