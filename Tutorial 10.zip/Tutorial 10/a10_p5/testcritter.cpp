//CH-230-B
//a10_p5       .cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include <cstdlib>
#include "Critter.h"
//Including header file

using namespace std;

int main(int argc, char** argv)
{
	Critter c;
	string name;
	int hunger;
 
	cout << endl << "Please enter data: " << endl;
	cout << "Name: ";
	// cin >> name; will not work if name contains
	// spaces
	getline(cin, name);
	c.setName(name);
	c.setName(name);
	cout << "Hunger: ";
	cin >> hunger;
	c.setHunger(hunger);

	cout << "You have created:" << endl;
	c.print();
	Critter instance1;
	instance1.print();
	//Making a new instance by deafult constructor and printing it
	Critter instance2("Rhino");
	instance2.print();
	//Making a new instance by constuctor with only name parameter
	//and printing it 
	Critter instance3("Harambe",56,23,3.6);
	instance3.print();
	//Making a new instance by constructor with all the parameters
	//and printing it
	Critter instance4("Oreo",45,23);
	instance4.print();
	//Making a new instance by constructor with all the parameters and not
	//passing the height and printing it
    return 0;
}