//CH-230-B
//a10_p5.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <string> // defines standard C++ string class

/* First C++ class */
class Critter
{
private:  // data members are private
	std::string name;
	int hunger;
	int boredom;
	double height;
	//Adding two extra properties

public: // business logic methods are public
	// setter methods
	void setName(std::string& newname);
	void setHunger(int newhunger);
	void setBoredom(int newboredom);
	//Seeting the new properties
	// getter method
	int getHunger();
	//Getting the two new attributes
	// service method
	void print();
	Critter();
	Critter(std::string);
	Critter(std::string,int,int,double  height = 0);
	//Decalring new constructors
};