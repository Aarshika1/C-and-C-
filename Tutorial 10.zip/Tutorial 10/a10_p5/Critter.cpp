//CH-230-B
//a10_p5.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include "Critter.h"
//Including header file
using namespace std;

void Critter::setName(string& newname) {
	name = newname;
}
void Critter::setHunger(int newhunger) {
	hunger = newhunger;
}
void Critter::print() {
	cout << "I am " << name << ". My hunger level is " << hunger << ", " <<"My boredom level is "<<boredom<<" and my height is "<<height<<endl;
}

int Critter::getHunger() {
	return hunger;
}
Critter::Critter()
{
	name="0";
	hunger=0;
	boredom=0;
	height=5;
	cout<<"Default constructor being called"<<endl;
}
//Defining the deafult constructor and setting all the 
//properties to zero
Critter::Critter(string namepar)
{
	name = namepar;
	hunger = 0;
	boredom = 0;
	height = 5;
	cout<<"Constructor with a name as a parameter being called"<<endl;

}
//Defining the constructor which take only a name as a parameter and
//sets height to 5, name to the parameter and others to 0
Critter::Critter(string namepar,int hungpar, int borepar, double heightpar)
{
	height = 10;
	name = namepar;
	hunger = hungpar;
	boredom = borepar;
	height = heightpar;
	cout<<"Constructor with all parameters defined being called"<<endl;
}
//Defining the constructor which takes all the parameters and 
//sets the properties accordingly and if the height is not passed,
//then the height is set to 10 by default