//CH-230-B
//a10_p6.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include "Critter.h"

using namespace std;

void Critter::setName(string& newname) {
	name = newname;
}

void Critter::setHunger(int newhunger) {
	hunger = double (newhunger)/10.0;
}

void Critter::print() {
	cout << "I am " << name << ". My hunger level is " <<(double)hunger/10 << ", " <<"My boredom level is "<<boredom<<" and my height is "<<height<<endl;
	//Converting hunger to double by typecasting and didviding by 10
}

int Critter::getHunger() {
	return (double)hunger*10;
}
Critter::Critter()
{
	name="0";
	hunger=0;
	boredom=0;
	height=5;
	cout<<"Default constructor being called"<<endl;
}
Critter::Critter(string namepar)
{
	name = namepar;
	hunger = 0;
	boredom = 0;
	height = 5;
	cout<<"Constructor with a name as a parameter being called"<<endl;

}
Critter::Critter(string namepar,int hungpar, int borepar, double heightpar)
{
	height = 10;
	name = namepar;
	hunger = (double)hungpar/10.0;
	boredom = borepar;
	height = heightpar;
	cout<<"Constructor with all parameters defined being called"<<endl;
}