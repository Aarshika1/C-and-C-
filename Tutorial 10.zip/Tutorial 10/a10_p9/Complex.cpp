//CH-230-B
//a10_p9.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<cmath>
#include "Complex.h"
//Including header
using namespace std;

void Complex::setcomplex(float re, float img)
{
    real = re;
    imaginary = img;
}
//Setter fucntion for the complex
//It takes two parameters each for the real and 
//Imaginary part and sets it to the properties
float Complex::getreal()
{
    return real;
}
//Getter for the real part
float Complex::getimaginary()
{
    return imaginary;
}
//getter for the imaginary part
void Complex::printComplex()
{
    char sign;
    if(imaginary>=0)
    {
        sign = '+';
    }
    else
    {
        sign = '-';
    }

    cout<<real<<sign<<abs(imaginary)<<"i"<<endl;
}
//Print function for the complex number
//If the imaginary is greater than 0, then + sign is printed
//otherwise - sign is used
Complex::Complex()
{
    real = 0.0;
    imaginary = 0.0;
}
//Default constructor sets the value to 0 for both
Complex::Complex(float r,float i)
{
    real = r;
    imaginary = i;
}
//Constructor sets the value to the given parameter
Complex::Complex(const Complex &c)
{
    real = c.real;
    imaginary = c.imaginary;

}
//Copy constructor is used to copy the properties 
//to the properties of the passed by reference complex c
Complex::~Complex()
{

}
//Empty destructor
Complex Complex::Conjugate()
{
    Complex complex;
    complex.real = real;
    complex.imaginary = -1*imaginary;
    return complex;
}
//The above method returns a complex
//It multiplies the imaginary by -1 to 
//convert the complex to its conjugate
Complex Complex::add(Complex complex)
{
    complex.real = real + complex.real;
    complex.imaginary = imaginary + complex.imaginary;
    return complex;
}
//The above add method takes in a complex and returns a complex
//It adds the real part to the real part of the complex 
//and the imaginary part to the imaginary part of the complex
Complex Complex::subtract(Complex complex)
{
    complex.real = real - complex.real;
    complex.imaginary = imaginary - complex.imaginary;
    return complex;
}
//The above subtract method takes in a complex and returns a complex
//It subtracts the real part fo the given complex from the real part of 
//the complex and imaginary part of the given complex from the iaginary part
Complex Complex::multiply(Complex complex)
{
    complex.real = real*complex.real;
    complex.imaginary = imaginary*complex.imaginary;
    return complex;
}
//The above mutliply methid takes in a complex and returns a complex
//It mulyiplies the real part of the complex by the real part 
//and the imaginary part by the imaginary part