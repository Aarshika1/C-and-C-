//CH-230-B
//a10_p9.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#ifndef COMPLEX_H_INCLUDED
#define COMPLEX_H_INCLUDED
using namespace std;
class Complex
{
    private:
    float real;
    float imaginary;
    //Declaring properties
    public:
    void setcomplex(float re, float img);
    //Setter for the complex
    float getreal();
    float getimaginary();
    //getter for the real and imaginary part
    void printComplex();
    Complex();
    //Empty constructor
    Complex(float r,float i);
    //Constructor with parameters
    Complex(const Complex &c);
    //Copy constructor
    ~Complex();
    //Destructor
    Complex Conjugate();
    Complex add(Complex);
    Complex subtract(Complex);
    Complex multiply(Complex);
    //Methods for operations

};

#endif // COMPLEX_H_INCLUDED
