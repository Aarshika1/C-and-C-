//CH-230-B
//a10_p9.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<cmath>
#include "Complex.h"
using namespace std;
int main()
{
    float R1,I1,R2,I2;
    cout<<"Real part of the first complex: ";
    cin>>R1;
    cout<<"Imaginary part of the first complex: ";
    cin>>I1;
    cout<<"Real part of the second complex: ";
    cin>>R2;
    cout<<"Imaginary part of the second complex: ";
    cin>>I2;
    //Reading the input
    Complex c1,c2;
    //making two instances
    c1.setcomplex(R1,I1);
    //Setting first instance
    c2.setcomplex(R2,I2);
    //Setting second instance
    Complex c1_cnj;
    c1_cnj = c1.Conjugate();
    //Calling conjugate function on the first instance
    c1_cnj.printComplex();
    //printing the conjugate
    Complex c3;
    c3 = c1.add(c2);
    //Calling the addition function
    c3.printComplex();
    //printing the addition
    Complex c4;
    c4 = c2.subtract(c1);
    //Calling the subtraction function
    c4.printComplex();
    //printing the subtraction
    Complex c5;
    c5 = c1.multiply(c2);
    //calling the multiplication function
    c5.printComplex();
    //printing the multiplication
    return 0;
}
