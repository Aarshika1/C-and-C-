//CH-230-B
//a10_p2.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include "Critter.h"

using namespace std;

void Critter::setName(string& newname) {
	name = newname;
}

void Critter::setHunger(int newhunger) {
	hunger = newhunger;
}
void Critter::setThirst(int newthirst){
	thirst = newthirst;
}
void Critter::setWeight(float newweight){
	weight = newweight;
}

void Critter::print() {
	cout << "I am " << name << ". My hunger level is " << hunger << ", " <<"My thirst level is "<<thirst<<" and my weight is "<<weight<<endl;
}

int Critter::getHunger() {
	return hunger;
}
int Critter::getThirst(){
	return thirst;
}
float Critter::getWeight(){
	return weight;
}