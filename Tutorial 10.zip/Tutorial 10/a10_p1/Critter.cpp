//CH-230-B
//a10_p1.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include "Critter.h"

//using namespace std;

setName(string& newname) {
	name = newname;
}

void Critter::setHunger(int newhunger) {
	hunger = newhunger;
}

void Critter::print() {
	cout << "I am " << name << ". My hunger level is " << hunger << "." << endl;
}

int Critter::getHunger() {
	return hunger;
}