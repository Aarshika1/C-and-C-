//CH-230-B
//a10_p7.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include "Critter.h"

using namespace std;

void Critter::setName(string& newname) {
	name = newname;
}

void Critter::setHunger(int newhunger) {
	hunger = newhunger;
}

void Critter::print() {
	cout << "I am " << name << ". My hunger level is " << (double)(hunger/10.0)<<","<<"My thirst level is: "<<thirst<< ", " <<"My boredom level is "<<boredom<<" and my height is "<<height<<endl;
}

int Critter::getHunger() {
	return hunger;
}
Critter::Critter()
{
	name="0";
	hunger=0;
	boredom=0;
	height=5;
	thirst = 0;
	//Setting thirst as the hunger
	cout<<"Default constructor being called"<<endl;
}
Critter::Critter(string namepar)
{
	name = namepar;
	hunger = 0;
	boredom = 0;
	height = 5;
	thirst = 0;
	//Setting thirst as hunger
	cout<<"Constructor with a name as a parameter being called"<<endl;

}
Critter::Critter(string namepar,int hungpar, int borepar, double heightpar)
{
	height = 10;
	name = namepar;
	hunger = hungpar;
	boredom = borepar;
	height = heightpar;
	thirst = hungpar;
	//Setting thirst as the hunger
	cout<<"Constructor with all parameters defined being called"<<endl;
}
Critter::Critter(string namepar,int hungpar,int borepar,double heightpar, double thirstpar)
{
	name = namepar;
	hunger = hungpar;
	boredom = borepar;
	height = heightpar;
	thirst = thirstpar;
	//Setting thirst as the parameter
	cout<<"Constructor with 5 paramters including thirst being called"<<endl;

}