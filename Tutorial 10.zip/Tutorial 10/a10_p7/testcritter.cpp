//CH-230-B
//a10_p7.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include <cstdlib>
#include "Critter.h"

using namespace std;

int main(int argc, char** argv)
{
	Critter c;
	string name;
	int hunger;
 
	cout << endl << "Please enter data: " << endl;
	cout << "Name: ";
	// cin >> name; will not work if name contains
	// spaces
	getline(cin, name);
	c.setName(name);
	c.setName(name);
	cout << "Hunger: ";
	cin >> hunger;
	c.setHunger(hunger);

	cout << "You have created:" << endl;
	c.print();
	Critter instance1;
	instance1.print();
	Critter instance2("Rhino");
	instance2.print();
	Critter instance3("Harambe",56,23,3.6);
	instance3.print();
	Critter instance4("Oreo",45,23);
	instance4.print();
	Critter instance5("Ash",58,64,3.4,9.5);
	instance5.print();
	//Constructing and printing new instance with thirst
    return 0;
}