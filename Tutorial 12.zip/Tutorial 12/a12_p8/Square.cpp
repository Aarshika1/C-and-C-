//CH-230-B
//a12_p8.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include<cmath>
#include "Square.h"

Square::Square(const char *n, double a,double b)
                            : Rectangle(n,a,b)
{
    side = a;
}
//Parametric constructor

Square::~Square() {
}
//Destructor

double Square::calcArea() const {
	std::cout << "calcArea of Square...";
	return side*side;
}
//Calculating area of a square

double Square::calcPerimeter() const {
    std::cout<<"calcPerimeter of Square...";
    return 4*side;

}
//Calculating perimeter of a square
