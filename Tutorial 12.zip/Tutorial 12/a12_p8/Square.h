//CH-230-B
//a12_p8.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#ifndef SQUARE_H_INCLUDED
#define SQUARE_H_INCLUDED
#include "Rectangle.h"

class Square : public Rectangle
{
    public:
        Square(const char *n, double a,double b=0);
        ~Square();
        //constructors
        double calcArea() const;
        double calcPerimeter() const;
        //methods
	private:
	    double side;
        //property

};



#endif // SQUARE_H_INCLUDED
