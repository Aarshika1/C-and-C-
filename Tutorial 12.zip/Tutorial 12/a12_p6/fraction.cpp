//CH-230-B
//a12_p6.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include "fraction.h"

Fraction::Fraction()
{
	num = 1;
	den = 1;
}

Fraction::Fraction(int n, int d)
{
	int tmp_gcd = gcd(n, d);

	num = n / tmp_gcd;
	den = d / tmp_gcd;
}

int Fraction::gcd(int a, int b)
{
	int tmp_gcd = 1;

	// Implement GCD of two numbers;

	return tmp_gcd;
}

int Fraction::lcm(int a, int b)
{
	return a * b / gcd(a, b);

}

// void Fraction::print()
// {
// 	std::cout << num << "/" << den << std::endl;
// }

std::ostream& operator << (std::ostream& os,const Fraction& fr)
{
	os<<fr.num<<"/"<<fr.den<<std::endl;
	return os;
}
//Overloading the << operator

std::istream& operator >> (std::istream& is, Fraction& fr)
{
	is>>fr.num>>fr.den;
	return is;
}
//Ovetloading the >> operator

Fraction Fraction::operator*(Fraction &fr)
{
	Fraction temp(num*fr.num,den*fr.den);
	return temp;
}
//Overloading * operator

Fraction Fraction::operator/(Fraction &fr)
{
	Fraction temp(den*fr.num,num*fr.den);
	return temp;
}
//Overlaoding / operator
