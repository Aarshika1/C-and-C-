//CH-230-B
//a12_p6.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include "fraction.h"

using namespace std;

int main(void)
{
	Fraction a(4, 2);
	Fraction b(17, 11);
	Fraction c(5);

	// a.print(); 
	// b.print(); 
	// c.print(); 
	cout << a;
	cout << b;
	cout << c;
	//Printing using operator overloading of << operator
	Fraction d,e;
	cin >> d;
	cin >> e;
	//Reading two new fractions using >> operator
	Fraction mult = e * d;
	//Calculating product using *
	cout<<"Product: ";
	cout << mult;
	Fraction div = e/d;
	//Calculating quotient using / operator
	cout<<"Quotient: ";
	cout << div;
}
