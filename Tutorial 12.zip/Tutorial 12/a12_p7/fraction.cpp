//CH-230-B
//a12_p7.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include "fraction.h"

Fraction::Fraction()
{
	num = 1;
	den = 1;
}

Fraction::Fraction(int n, int d)
{
	int tmp_gcd = gcd(n, d);

	num = n / tmp_gcd;
	den = d / tmp_gcd;
}

int Fraction::gcd(int a, int b)
{
	if(b==0)
	{
		return a;
	}
	return gcd(b,a%b);
}
//Computing gcd of two fractions

int Fraction::lcm(int a, int b)
{
	return a * b / gcd(a, b);

}

// void Fraction::print()
// {
// 	std::cout << num << "/" << den << std::endl;
// }

std::ostream& operator << (std::ostream& os,const Fraction& fr)
{
	os<<fr.num<<"/"<<fr.den<<std::endl;
	return os;
}
//Overlaoding << for printing

std::istream& operator >> (std::istream& is, Fraction& fr)
{
	is>>fr.num>>fr.den;
	return is;
}
//Overloading >> for reading input

Fraction Fraction::operator*(Fraction &fr)
{
	Fraction temp(num*fr.num,den*fr.den);
	return temp;
}
//Overlaoding * to compute product

Fraction Fraction::operator/(Fraction &fr)
{
	Fraction temp(den*fr.num,num*fr.den);
	return temp;
}
//Overloading / to compute quotient

Fraction Fraction::operator+(Fraction &fr)
{
	int n = num*fr.den+fr.num*den;
	int d = den*fr.den;
	Fraction temp(n,d);
	return temp;
}
//Overlaoding + to compte sum

Fraction Fraction::operator-(Fraction &fr)
{
	int n = fr.num*den-num*fr.den;
	int d = den*fr.den;
	Fraction temp(n,d);
	return temp;
}
//Overloading - to compute difference

Fraction& Fraction::operator=(Fraction &fr)
{
	this->num = fr.num;
	this->den = fr.den;
	return *this;
}
//Overloading = to assign

bool operator>(Fraction &fr1,Fraction &fr2)
{
	return fr1.num*fr2.den>fr2.num*fr1.den;

}
//Overlaoding > to check the larger value

bool operator<(Fraction &fr1, Fraction &fr2)
{
	return fr1.num*fr2.den<fr2.num*fr1.den;
}
//Overlaoding < to check the smaller value