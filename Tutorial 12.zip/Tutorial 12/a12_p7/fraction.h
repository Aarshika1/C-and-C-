//CH-230-B
//a12_p7.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
// simple class for fractions

#ifndef FRACTION_H_
#define FRACTION_H_
#include<iostream>

class Fraction {

private:						// internal implementation is hidden
	int num;					// numerator
	int den;					// denominator

	int gcd(int a, int b);		// calculates the gcd of a and b
	int lcm(int a, int b);

public:
	Fraction();					// empty constructor
	Fraction(int, int = 1); 	// constructor taking values for fractions and
								// integers. Denominator by default is 1
	void print();				// prints it to the screen
	friend std::ostream& operator<<(std::ostream& os,const Fraction& fr);
	friend std::istream& operator>>(std::istream& is, Fraction& fr);
	Fraction operator*(Fraction &);
	Fraction operator/(Fraction &);
	Fraction operator+(Fraction &);
	Fraction operator-(Fraction &);
	Fraction& operator=(Fraction &);
	friend bool operator>(Fraction &,Fraction &);
	friend bool operator<(Fraction &,Fraction &);
	
	//Declaring operator overlaoding fucntions
};


#endif /* FRACTION_H_ */
