//CH-230-B
//a12_p7.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include "fraction.h"

using namespace std;

int main(void)
{
	Fraction a(4, 2);
	Fraction b(17, 11);
	Fraction c(5);

	// a.print(); 
	// b.print(); 
	// c.print(); 
	cout << a;
	cout << b;
	cout << c;
	Fraction d,e;
	cout<<"First Fraction: ";
	cin >> d;
	cout<<"Second Fraction: ";
	cin >> e;
	//Reading new fractions
	// Fraction mult = e * d;
	// cout<<"Product: ";
	// cout << mult;
	// Fraction div = e / d;
	// cout<<"Quotient: ";
	// cout << div;
	if(e > d)
	{
		cout<<"Greater: ";
		cout << e;
	}
	else if(e < d)
	{
		cout << "Greater: ";
		cout << d;
	}
	//Cgecking the greater fraction
	cout << "Sum: ";
	Fraction add = e + d;
	cout << add;
	//computing the sum and printing it
	cout << "Difference: ";
	Fraction diff = e - d;
	cout << diff;
	//computing tthe differenece and printing it
	

	return 0;

}
