//CH-230-B
//a12_p3.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<cstring>
#include "TournamentMember.h"

std::string TournamentMember::location="Bremen";
//setting the static property
TournamentMember::TournamentMember()
{
    std::cout<<"Default constructor being called"<<std::endl;
    strcpy(Firstname,"Default");
    strcpy(Lastname,"Default");
    strcpy(DOB,"0000-00-00");
    location = "Default";
    Age = 0;
    Height = 0.0;
}
//Default contructor

TournamentMember::TournamentMember(char *firstpar,char *lastpar,char* dobpar,int agepar,double heightpar)
{
    std::cout<<"Parametric Constructor being called"<<std::endl;
    strcpy(Firstname,firstpar);
    strcpy(Lastname,lastpar);
    strcpy(DOB,dobpar);
    Age = agepar;
    Height = heightpar;

}
//Parametric constructor

TournamentMember::TournamentMember(const TournamentMember &c)
{
    std::cout<<"Copy constructor being called"<<std::endl;
    strcpy(Firstname,c.Firstname);
    strcpy(Lastname,c.Lastname);
    strcpy(DOB,c.DOB);
    Age = c.Age;
    Height = c.Height;
}
//Copy constructor

TournamentMember::~TournamentMember()
{
    std::cout<<"Destructor being called"<<std::endl;
}
//Destructor

void TournamentMember::print()
{
    std::cout<<"Name: "<<Firstname<<" "<<Lastname<<std::endl;
    std::cout<<"Date of Birth: "<<DOB<<std::endl;
    std::cout<<"Location: "<<location<<std::endl;
    std::cout<<"Age: "<<Age<<std::endl;
    std::cout<<"Height: "<<Height<<std::endl;

}
//Print function
void TournamentMember::changelocation(std::string change)
{
    std::cout<<"Changing location...."<<std::endl;
    location = change;
}
//Change location fucntion
Player::Player(char *firstpar,char *lastpar,char *dobpar,int agepar,double heightpar,int numpar,std::string pospar,int goalpar,std::string footpar) :
    TournamentMember(firstpar,lastpar,dobpar,agepar,heightpar)
{
    std::cout<<"Parametric constructor for players being called"<<std::endl;
    number = numpar;
    position = pospar;
    goals = goalpar;
    left_right = footpar;
}
//Parametric function for players class

Player::Player(const Player &c)
{
    std::cout<<"Copy constructor for players being called"<<std::endl;
    number = c.number;
    position = c.position;
    goals = c.goals;
    left_right = c.left_right;
}
//Copy constructor for players class
Player::~Player()
{
    std::cout<<"Destructor for players being called"<<std::endl;

}
//Destructor for players class
void Player::printp()
{
    std::cout<<"Player number: "<<number<<std::endl;
    std::cout<<"Player's position: "<<position<<std::endl;
    std::cout<<"Number of goals: "<<goals<<std::endl;
    std::cout<<"Player foot: "<<left_right<<std::endl;
}
//Print fucntion for players class
int Player::incre_goals()
{
    int increment;
    increment = goals+1;
    return increment;
}
//Goal increasing function for players class