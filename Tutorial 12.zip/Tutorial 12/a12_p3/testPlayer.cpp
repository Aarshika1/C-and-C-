//CH-230-B
//a12_p3.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<cstring>
#include "TournamentMember.h"
int main()
{
    char n[36]="Ronaldo";
    char ln[36]="Messi";
    char db[11]="1995-06-18";
    Player p1(n,ln,db,25,182.3,10,"Middle",65,"Right");
    p1.print();
    p1.printp();
    //Calling and printing parametric constructor
    char n2[36]="Jacobs";
    char ln2[36]="University";
    char db2[11]="2001-12-16";
    Player p2(n2,ln2,db2,36,190.2,16,"Front",89,"Left");
    p2.print();
    p2.printp();
    //Calling an dprinting parametric constructir
    Player p3(p1);
    p3.print();
    p3.printp();
    //Calling and printing copy constructor
    p1.changelocation("Hamburg");
    p1.print();
    p1.printp();
    p2.changelocation("Hamburg");
    p2.print();
    p2.printp();
    p3.changelocation("Hamburg");
    p3.print();
    p3.printp();
    //Changing location to hamburg
    return 0;
}