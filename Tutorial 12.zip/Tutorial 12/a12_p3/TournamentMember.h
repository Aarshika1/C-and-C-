//CH-230-B
//a12_p3.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#ifndef TOURNAMENTMEMBER_H_INCLUDED
#define TOURNAMENTMEMBER_H_INCLUDED
#include<iostream>
#include<cstring>
using namespace std;
class TournamentMember
{
    private:
        char Firstname[36];
        char Lastname[36];
        char DOB[11];
        static string location;
        //static attribute
        int Age;
        double Height;
        //attributes
    public:
        TournamentMember();
        TournamentMember(char*,char*,char*,int,double);
        TournamentMember(const TournamentMember&);
        //Constructors
        ~TournamentMember();
        //Destructor
        void setFirstName(char *fn){strcpy(Firstname,fn);}
        void setLastName(char *ln){strcpy(Lastname,ln);}
        void setDOB(char *dob){strcpy(DOB,dob);}
        void setAge(int a){Age = a;}
        void setHeight(double h){Height = h;}
        //Setter methods
        char* getFirstName(){return Firstname;}
        char* getLastName(){return Lastname;}
        char* getDOB(){return DOB;}
        int getAge(){return Age;}
        double getHeight(){return Height;}
        //Getter methods
        void print();
        //print method 
        static void changelocation(string);
        //location change method
};

class Player : public TournamentMember
//new inherited class
{
    private:
        int number;
        std::string position;
        int goals;
        std::string left_right;
        //attributes
    public:
        void setnumber(int n){number = n;}
        void setposition(std::string pos){position = pos;}
        void setfoot(std::string lr){left_right = lr;}
        //setter methods
        int getnumber(){return number;}
        std::string getposition(){return position;}
        int getgoals(){return goals;}
        std::string getfoot(){return left_right;}
        //getter methods
        Player(char*,char*,char*,int,double,int,std::string,int,std::string);
        Player(const Player&);
        //constructor
        ~Player();
        //destructor
        void printp();
        //print function
        int incre_goals();
        //goal incrementing fucntion
};


#endif // TOURNAMENTMEMBER_H_INCLUDED
