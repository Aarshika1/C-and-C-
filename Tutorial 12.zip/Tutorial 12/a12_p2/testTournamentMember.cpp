//CH-230-B
//a12_p2.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<string>
#include "TournamentMember.h"
int main()
{
    char n[36] = "Aarshika";
    char ln[36] = "Singh";
    char dob[11] = "2000-02-06";
    //Making arrays
    TournamentMember tm1(n,ln,dob,19,162.3);
    //Setting arrays as parameters for the parametric constructor
    tm1.print();
    TournamentMember tm2;
    //Calling default contructor
    tm2.print();
    TournamentMember tm3(tm1);
    //Calling copy constructor
    tm3.print();
    tm3.changelocation("Germany");
    //Changing location
    tm3.print();
    return 0;

}