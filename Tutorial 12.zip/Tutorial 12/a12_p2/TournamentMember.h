//CH-230-B
//a12_p2.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#ifndef TOURNAMENTMEMBER_H_INCLUDED
#define TOURNAMENTMEMBER_H_INCLUDED
#include<iostream>
#include<cstring>
using namespace std;
class TournamentMember
{
    private:
        char Firstname[36];
        char Lastname[36];
        char DOB[11];
        static std::string location;
        //static attribute
        int Age;
        double Height;
        //attributes
    public:
        TournamentMember();
        //Default constructor
        TournamentMember(char*,char*,char*,int,double);
        //Parametric constructor
        TournamentMember(const TournamentMember&);
        //Copy constructor
        ~TournamentMember();
        void setFirstName(char *fn){strcpy(Firstname,fn);}
        void setLastName(char *ln){strcpy(Lastname,ln);}
        void setDOB(char *dob){strcpy(DOB,dob);}
        void setAge(int a){Age = a;}
        void setHeight(double h){Height = h;}
        //setter methods
        char* getFirstName(){return Firstname;}
        char* getLastName(){return Lastname;}
        char* getDOB(){return DOB;}
        int getAge(){return Age;}
        double getHeight(){return Height;}
        //gettter methods
        void print();
        //printing function
        static void changelocation(std::string);
        //changing location fucntion which is also static 
};

#endif // TOURNAMENTMEMBER_H_INCLUDED
