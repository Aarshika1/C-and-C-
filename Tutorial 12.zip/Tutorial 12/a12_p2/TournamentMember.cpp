//CH-230-B
//a12_p2.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<cstring>
#include "TournamentMember.h"

std::string TournamentMember::location = "India";
//Setting the static property

TournamentMember::TournamentMember()
{
    std::cout<<"Default constructor being called"<<std::endl;
    strcpy(Firstname,"Default");
    strcpy(Lastname,"Default");
    strcpy(DOB,"0000-00-00");
    Age = 0;
    Height = 0.0;
}
//Deafult constructor

TournamentMember::TournamentMember(char *firstpar,char *lastpar,char *dobpar,int agepar,double heightpar)
{
    std::cout<<"Parametric Constructor being called"<<std::endl;
    strcpy(Firstname,firstpar);
    strcpy(Lastname,lastpar);
    strcpy(DOB,dobpar);
    Age = agepar;
    Height = heightpar;

}
//Parametric constructor

TournamentMember::TournamentMember(const TournamentMember &c)
{
    std::cout<<"Copy constructor being called"<<std::endl;
    strcpy(Firstname,c.Firstname);
    strcpy(Lastname,c.Lastname);
    strcpy(DOB,c.DOB);
    Age = c.Age;
    Height = c.Height;
}
//Copy constructor

TournamentMember::~TournamentMember()
{
    std::cout<<"Destructor being called"<<std::endl;
}
//Destructor

void TournamentMember::print()
{
    std::cout<<"Name: "<<Firstname<<" "<<Lastname<<std::endl;
    std::cout<<"Date of Birth: "<<DOB<<std::endl;
    std::cout<<"Location: "<<location<<std::endl;
    std::cout<<"Age: "<<Age<<std::endl;
    std::cout<<"Height: "<<Height<<std::endl;

}
//Printing function
void TournamentMember::changelocation(std::string change)
{
    std::cout<<"Changing location..."<<std::endl;
    location = change;
}
//Changing location function