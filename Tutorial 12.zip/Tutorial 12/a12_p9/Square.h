#ifndef SQUARE_H_INCLUDED
#define SQUARE_H_INCLUDED
#include "Rectangle.h"

class Square : public Rectangle
{
    public:
        Square(const char *n, double a,double b=0);
        ~Square();
        double calcArea() const;
        double calcPerimeter() const;
	private:
	    double side;

};



#endif // SQUARE_H_INCLUDED
