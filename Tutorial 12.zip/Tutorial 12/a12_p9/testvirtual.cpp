//CH-230-B
//a12_p9.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include<time.h>
#include<cmath>
using namespace std;
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"
 
const int num_obj = 25;
int main()
{
	srand(time(NULL));
	//seeding the random number
	for(int i=0;i<25;i++)
	//using for loop for iterating 25 times
	{
		const char* Colors[4] = {"RED","BLACK","VIOLET","BLUE"};
		//Making an array of colors
        int random = rand() % 4;
		double randomsize1 = (rand() % 96)+5;
		double randomsize2 = (rand() % 96)+5;
		//Taking random numbers
		const std::string Object[4]= {"Circle","Ring","Rectangle","Square"};
		//Making an array of shapes
		int randomob = rand() % 4;
		if(Object[randomob]=="Circle")
		{
			Circle c1(Colors[random],randomsize1);
			double area = abs(c1.calcArea());
			cout<<"Area: "<<area<<endl;
			double per = abs(c1.calcPerimeter());
			cout<<"Perimeter: "<<per<<endl;
		}
		//If the random shapes selected is circle then a circle
		//with random parameters is constructed
		else if(Object[randomob]=="Ring")
		{
			Ring r1(Colors[random],randomsize1,randomsize2);
			double area = abs(r1.calcArea());
			cout<<"Area: "<<area<<endl;
			double per = abs(r1.calcPerimeter());
			cout<<"Perimeter: "<<per<<endl;
		}
		//If the random shapes selected is ring then a ring
		//with random parameters is constructed
	
		else if(Object[random]=="Rectangle")
		{
			Rectangle rec1(Colors[random],randomsize1,randomsize2);
			double area = abs(rec1.calcArea());
			cout<<"Area: "<<area<<endl;
			double per = abs(rec1.calcPerimeter());
			cout<<"Perimeter: "<<per<<endl;
		}
		//If the random shapes selected is rectangle then a rectangle
		//with random parameters is constructed
		

		else if(Object[random]=="Square")
		{
			Square s1(Colors[random],randomsize1);
			double area = abs(s1.calcArea());
			cout<<"Area: "<<area<<endl;
			double per = abs(s1.calcPerimeter());
			cout<<"Perimeter: "<<per<<endl;
		}
		//If the random shapes selected is square then a square
		//with random parameters is constructed
		

	}




	return 0;
}
