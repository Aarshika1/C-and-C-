#include<stdio.h>
float sum(int n,float values[])
{
    float sum = 0;
    for(int i = 0; i < n && values[i] != -99.0; i++)
    {
        sum = sum + values[i];
    }
    return sum;
}
float average(int n,float values[])
{
    float sum = 0;
    float average = 0;
    for(int i = 0; i < n && values[i] != -99.0; i++)
    {
        sum = sum + values[i];
        average = sum/(i+1);
    }
    
    return average;
}
int main()
{
    float array[10];
    for(int i = 0; i<10;i++)
    {
        scanf("%f",&array[i]);
        if(array[i]==-99.0)
        {
            break;
        }
    }
    float sum1 = sum(10,array);
    printf("%f\n",sum1);
    float average1 = average(10,array);
    printf("%f\n",average1);
    return 0;
}