//CH-230-B
//a12_p1.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
// please refer to shapes.h for methods documentation

#include <iostream>
#include<cmath>
#include "Shapes.h"

using namespace std; 

Shape::Shape(const string& n) : name(n) {
}

void Shape::printName() const {
	cout << name << endl;
}

CenteredShape::CenteredShape(const string& n, double nx, double ny): Shape(n) {
	x = nx;
	y = ny;
}

RegularPolygon::RegularPolygon(const string& n, double nx, double ny, int nl) :
	CenteredShape(n,nx,ny) 
{
	EdgesNumber = nl;
}

Circle::Circle(const string& n, double nx, double ny, double r) : 
  CenteredShape(n,nx,ny) 
{
	Radius = r;
}

double Hexagon::perimeter()
{
    double per;
    per = 6*side;
    return per;
}
//The above function computes the perimeter of 
//a hexagon. It takes in nothing and returns a 
//double

double Hexagon::area()
{
    double area;
    area = ((3*((pow(3,0.5)*side*side)/2)));
    return area;
}
//The above fucntion computes the area of 
//a hexagon. It takes in nothing and 
//returns a double

void Hexagon::setside(double sidepar){side=sidepar;}
//Setter method definition for the side of a hexagon

void Hexagon::setcolor(std::string colorpar){color=colorpar;}
//Setter method definition for the color of a hexagon

double Hexagon::getside(){return side;}
//Getter method definition for the size of a hexagon

std::string Hexagon::getcolor(){return color;}
//Getter method definition for the color of a hexagon

Hexagon::Hexagon(const std::string &n,double nx,double ny,int nl,double sidepar,std::string colorpar) :
    RegularPolygon(n,nx,ny,nl)
{
    side = sidepar;
    color = colorpar;
}
//Parametric constructor for a hexagon

Shape::Shape()
{
    name = "Default";
}
//Default constructor for the class Shape

CenteredShape::CenteredShape()
{
    x = 0.0;
    y = 0.0;
}
//Default constructor for the class CenteredShape

RegularPolygon::RegularPolygon()
{
    EdgesNumber = 0;
}
//Default constructor for the class RegularPolygon

Hexagon::Hexagon()
{
    side = 0.0;
    color = "yellow";
}
//Default constructor for a Hexagon

Shape::Shape(const Shape &c)
{
    name = c.name;
}
//Copy constructor for the class Shape

CenteredShape::CenteredShape(const CenteredShape &c)
{
    x = c.x;
    y = c.y;
}
//Copy constructor for the class CenteredShape

RegularPolygon::RegularPolygon(const RegularPolygon &c)
{
    EdgesNumber = c.EdgesNumber;
}
//Copy constructor for the class RegularPolygon

Hexagon::Hexagon(const Hexagon &c)
{
    side=c.side;
    color=c.color;
}
//Copy constructor for a Hexagon