//CH-230-B
//a12_p1.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include "Shapes.h"
//Including header file

int main()
{
    Hexagon h1("Hexagon1",1,1,6,9,"Blue");
    //Creating a hexagon using parametric constructor
    Hexagon h2("Hexagon2",2,2,6,15,"Green");
    //Creating a hexagon using parametric constructor
    Hexagon h3(h2);
    //Creating a hexagon using copy constructor and
    //and copying the second hexagon
    double per1,per2,per3,area1,area2,area3;
    per1 = h1.perimeter();
    std::cout<<"Perimeter of the first hexagon: "<<per1<<std::endl;
    area1 = h1.area();
    std::cout<<"Area of the first hexagon: "<<area1<<std::endl;
    per2 = h2.perimeter();
    std::cout<<"Perimeter of the second hexagon: "<<per2<<std::endl;
    area2 = h2.area();
    std::cout<<"Area of the second hexagon: "<<area2<<std::endl;
    per3 = h3.perimeter();
    std::cout<<"Perimeter of the third hexagon: "<<per3<<std::endl;
    area3 = h3.area();
    std::cout<<"Area of the third hexagon: "<<area3<<std::endl;
    //Calculating area and perimeters and storing the values in a double 
    //and printing the value using cout function

    return 0;

}