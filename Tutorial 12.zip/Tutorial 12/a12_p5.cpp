//CH-230-B
//a12_p5.cpp
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<cstring>
//Including libraries
int main()
{
    int count = 0;
    //Counter variable
    srand(time(NULL));
    //Seeding random generator
    while(count<15)
    //Till the counter variable is less than 15
    {
        const std::string Colors[4] = {"RED","BLACK","VIOLET","BLUE"};
        //Making an array of the colors
        int random = rand() % 4;
        //Generating random number from 0 to 3
        std::cout<<"Random color is: "<<Colors[random]<<std::endl;
        //Using random number as the index for the array and printing
        //the random color
        count++;
        //incrementing counter variable

    }
    return 0;

}