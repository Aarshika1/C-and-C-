#ifndef TOURNAMENTMEMBER_H_INCLUDED
#define TOURNAMENTMEMBER_H_INCLUDED
#include<iostream>
#include<cstring>
using namespace std;
class TournamentMember
{
    private:
        char Firstname[36];
        char Lastname[36];
        char DOB[11];
        static string location;
        int Age;
        double Height;
    public:
        TournamentMember();
        TournamentMember(char*,char*,char*,int,double);
        TournamentMember(const TournamentMember&);
        ~TournamentMember();
        void setFirstName(char *fn){strcpy(Firstname,fn);}
        void setLastName(char *ln){strcpy(Lastname,ln);}
        void setDOB(char *dob){strcpy(DOB,dob);}
        void setAge(int a){Age = a;}
        void setHeight(double h){Height = h;}
        char* getFirstName(){return Firstname;}
        char* getLastName(){return Lastname;}
        char* getDOB(){return DOB;}
        int getAge(){return Age;}
        double getHeight(){return Height;}
        void print();
        static void changelocation(std::string);
};

class Player : public TournamentMember
{
    private:
        int number;
        std::string position;
        int goals;
        std::string left_right;
    public:
        void setnumber(int n){number = n;}
        void setposition(std::string pos){position = pos;}
        void setfoot(std::string lr){left_right = lr;}
        int getnumber(){return number;}
        std::string getposition(){return position;}
        int getgoals(){return goals;}
        std::string getfoot(){return left_right;}
        Player(char*,char*,char*,int,double,int,std::string,int,std::string);
        Player(const Player&);
        ~Player();
        void printp();
        int incre_goals();
};

class Referee : public TournamentMember 
{
    private:
        int yellowCardCount;
        Player *yellowCardList[40];
        int redCardCount;
        Player *redCardList[40];

    public:
        bool addtoYellowCardList(Player*);
        bool addtoRedCardList(Player*);
        void printr();
        Referee();
};

#endif // TOURNAMENTMEMBER_H_INCLUDED
