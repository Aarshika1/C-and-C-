#include<iostream>
#include<cstring>
#include<cstdbool>
#include "TournamentMember.h"

std::string TournamentMember::location = "Bremen";

TournamentMember::TournamentMember()
{
    std::cout<<"Default constructor being called"<<std::endl;
    strcpy(Firstname,"Default");
    strcpy(Lastname,"Default");
    strcpy(DOB,"0000-00-00");
    location = "Default";
    Age = 0;
    Height = 0.0;
}

TournamentMember::TournamentMember(char *firstpar,char *lastpar,char* dobpar,int agepar,double heightpar)
{
    std::cout<<"Parametric Constructor being called"<<std::endl;
    strcpy(Firstname,firstpar);
    strcpy(Lastname,lastpar);
    strcpy(DOB,dobpar);
    Age = agepar;
    Height = heightpar;

}

TournamentMember::TournamentMember(const TournamentMember &c)
{
    std::cout<<"Copy constructor being called"<<std::endl;
    strcpy(Firstname,c.Firstname);
    strcpy(Lastname,c.Lastname);
    strcpy(DOB,c.DOB);
    Age = c.Age;
    Height = c.Height;
}

TournamentMember::~TournamentMember()
{
    std::cout<<"Destructor being called"<<std::endl;
}

void TournamentMember::print()
{
    std::cout<<"Name: "<<Firstname<<" "<<Lastname<<std::endl;
    std::cout<<"Date of Birth: "<<DOB<<std::endl;
    std::cout<<"Location: "<<location<<std::endl;
    std::cout<<"Age: "<<Age<<std::endl;
    std::cout<<"Height: "<<Height<<std::endl;

}
void TournamentMember::changelocation(std::string change)
{
    location=change;
}
Player::Player(char *firstpar,char *lastpar,char *dobpar,int agepar,double heightpar,int numpar,std::string pospar,int goalpar,std::string footpar) :
    TournamentMember(firstpar,lastpar,dobpar,agepar,heightpar)
{
    std::cout<<"Parametric constructor for players being called"<<std::endl;
    number = numpar;
    position = pospar;
    goals = goalpar;
    left_right = footpar;
}

Player::Player(const Player &c)
{
    std::cout<<"Copy constructor for players being called"<<std::endl;
    number = c.number;
    position = c.position;
    goals = c.goals;
    left_right = c.left_right;
}
Player::~Player()
{
    std::cout<<"Destructor for players being called"<<std::endl;

}
void Player::printp()
{
    std::cout<<"Player number: "<<number<<std::endl;
    std::cout<<"Player's position: "<<position<<std::endl;
    std::cout<<"Number of goals: "<<goals<<std::endl;
    std::cout<<"Player foot: "<<left_right<<std::endl;
}
int Player::incre_goals()
{
    int increment;
    increment = goals+1;
    return increment;
}


bool Referee::addtoYellowCardList(Player *p)
{
    if(yellowCardCount>=40)
    {
        std::cout<<"Overflow..."<<std::endl;
        return false;
    }
    else
    {
        int flag =-1;
        for(int i=0;i<yellowCardCount;i++)
        {
            if(yellowCardList[i]==p)
            {
                flag = i;
                break;
            }
        }
    
    if(flag == -1)
    {
        yellowCardList[yellowCardCount]=p;
        yellowCardCount++;
        std::cout<<"Adding in yellow card..."<<std::endl;
        return true;
    }
    else
    {
        for(int i=flag;i<yellowCardCount-1;i++)
        {
            yellowCardList[i]=yellowCardList[i+1];
        }
        yellowCardCount--;
        if(addtoYellowCardList(p)==true)
        {
            std::cout<<"Already in yellow card.Moving to red card list"<<std::endl;
            return(addtoRedCardList(p));
        }
        else
        {
            return false;
        }
        
    }
  }
}

bool Referee::addtoRedCardList(Player *p)
{
    if(redCardCount>=40)
    {
        std::cout<<"Overflow..."<<std::endl;
        return false;
    }
    else
    {
        int flag =-1;
        for(int i=0;i<redCardCount;i++)
        {
            if(redCardList[i]==p)
            {
                flag = i;
                break;
            }
        }
        if(flag == -1)
        {
            redCardList[redCardCount]=p;
            redCardCount++;
            std::cout<<"Adding in red card..."<<std::endl;
            return true;
        }
        else
        {
            return false;
        }
        
    }
}

void Referee::printr()
{
    int i;
    std::cout<<"Yellow Card List"<<std::endl;
    for(i=0;i<yellowCardCount;i++)
    {
        std::cout<<yellowCardList[i]->getFirstName() << " " << 
                        yellowCardList[i]->getLastName() << std::endl;

    }
    std::cout<<"Red Card List"<<std::endl;
    for(int j=0;j<redCardCount;j++)
    {
        std::cout<<redCardList[i]->getFirstName() << " " <<
                        redCardList[i]->getLastName() << std::endl;
    }
}
Referee::Referee()
{
    std::cout<<"Default construtor for referee being called"<<std::endl;
    yellowCardCount=0;
    redCardCount=0;

}
