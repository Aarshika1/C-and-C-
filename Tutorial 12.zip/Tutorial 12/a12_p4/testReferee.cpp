#include<iostream>
#include<cstring>
#include "TournamentMember.h"

int main()
{
    Referee R1;
    char n1[36]="Ronaldo";
    char ln1[36]="Messi";
    char db1[11]="1995-06-18";
    Player p1(n1,ln1,db1,25,182.3,10,"Middle",65,"Right");
    char n2[36]="Jacobs";
    char ln2[36]="University";
    char db2[11]="2001-12-16";
    Player p2(n2,ln2,db2,36,190.2,16,"Front",89,"Left");
    char n3[36]="Player";
    char ln3[36]="3";
    char db3[11]="1998-05-07";
    Player p3(n3,ln3,db3,27,181.54,5,"Rear",45,"Right");
    Player p5(p2);
    p5.changelocation("Hamburg");
    char n4[36]="Computer";
    char ln4[36]="Science";
    char db4[11]="1900-12-12";
    Player p6(n4,ln4,db4,64,161.48,7,"Front",99,"Right");
    R1.addtoYellowCardList(&p1);
    R1.printr();
    R1.addtoYellowCardList(&p2);
    R1.printr();
    R1.addtoYellowCardList(&p5);
    R1.printr();
    R1.addtoRedCardList(&p1);
    R1.printr();
    R1.addtoYellowCardList(&p2);
    R1.printr();
    return 0;

}