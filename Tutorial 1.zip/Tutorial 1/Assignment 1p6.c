/*
    CH-230-B
    a1_p6.c
    Aarshika Singh
    aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    char c='F';
    c=c+3;

    printf("Third character after c = %c\nASCII value = %d\n",c,c);
    return 0;
}
