/*
   CH-230-B
   a1_p4.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    int x=17;
    int y=4;
    float division=(float)x/y;
    printf("x=%i\n",x);
    printf("y=%i\n",y);
    printf("sum=%i\n",x+y);
    printf("product=%i\n",x*y);
    printf("difference=%i\n",x-y);
    printf("division=%f\n",division);
    printf("remainder of division=%i\n",x%y);

    return 0;

}
