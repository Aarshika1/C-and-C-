/*
   CH-230-A
   a1_p5.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    int x=2138;
    printf("x=%9i\n",x);
    float y=(-52.358925);
    printf("y=%11.5f\n",y);
    char z='G';
    printf("z=%c\n",z);
    double u=(61.295339687);
    printf("u=%.7lf\n",u);


     return 0;

}
