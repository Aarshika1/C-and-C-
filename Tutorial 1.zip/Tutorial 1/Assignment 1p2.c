/*
   CH-230-B
   a1_p2.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
int main()
{
    int result;
    /*The result of our calculation*/
    result=(((2+7)*9)/3);
    printf("The result is %d\n",result);
    return 0;
    /*The answer was coming to be 4200624 because the variable result was not being inserted in the printf
    function.*/
}
