/*
   CH-230-B
   a7_p6.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*Including libraries*/

typedef struct person
{
    char name [30];
    int age;
}people;
/*Making a structure*/

void bubblesort(people *p, int size,int func(const people *p1, const people *p2))
{
int i, j;

 for(i=0;i<size; i++)
    {
        for(j=0; j <size-1; j++)
        {
            if (func( &p[j+1], &p[j] ) < 0 )
            {
                people temp = p[j+1];
                p[j+1] = p[j];
                p[j] = temp;
            }
        }
    }
}
/*The above function
1)Takes in a struct pointer, size of the array,
and a function which returns an integer and takes in two
const pointers.
2) Using nested for loops, uses func to compare the value
of two elements of the array and if the value is less than
zero, swaps the value of the two elements*/

int name( const people *p1, const people *p2 )
{
    int a = strcmp( p1->name, p2->name );
    int b = ( p2->age < p1->age ) - ( p1->age < p2->age );

    if(a!=0)
    {
        return a;
    }
    else
    {
        return b;
    }
}
/*The above function is used to compare the names.
1) It takes in two const struct pointers and uses two integers
to compare the names and the ages, if the names are not same,
then they are arranged accordingly.
2) If the names are same, then the ages are compared and
the names are arranged according to the ages*/

int age( const people *p1, const people *p2 )
{
    int a = strcmp( p1->name, p2->name );
    int b = ( p2->age < p1->age ) - ( p1->age < p2->age );

    if(b!=0)
    {
        return b;
    }
    else
    {
        return a;
    }

}
/*The above function works in the same manner as the name
function does. it just arranges according to the ages, but if the
ages are same, the they are arranged according to the names*/

int main()
{

int size, i;
people *p;

scanf("%d", &size);
/*Scanning the size of the list of
people*/
getchar();

p=(people *)malloc(sizeof(people)*size);
if(p==NULL)
{
    exit(0);
}
/*Dynamically allocating the memory*/
for(i=0;i<size;i++)
{
    fgets(p[i].name, 30, stdin);
    p[i].name[strlen(p[i].name)-1]='\0';
    scanf("%d", &p[i].age);
    getchar();
}
/*Reading the names and the ages*/
bubblesort(p,size,name);

 for(i=0;i<size;i++)
 {
   printf("{%s, %d}; ", p[i].name, p[i].age);

 }
 /*Calling the bubblesort for the names*/
 printf("\n");
 bubblesort(p,size,age);

 for(i=0;i<size;i++)
 {
   printf("{%s, %d}; ", p[i].name, p[i].age);

 }
 /*Calling the bubblesort for the ages*/
 printf("\n");
 return 0;
 }
