/*
   CH-230-B
   a7_p4.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>
#include <string.h>
/*Including Libraries*/
void upperorlower(char *string)
{
    int c;
    for(c=0;c<strlen(string);c++)
    {
      if (isupper(string[c]))
         {
             char a = tolower(string[c]);
             printf("%c",a);
         }
      else if (islower(string[c]))
         {
             char b = toupper(string[c]);
             printf("%c",b);
         }
        else
        {
            printf("%c",string[c]);
        }
        

    }
}
/*The above function-
1) Takes in a character pointer string.
2) And in a for loop checks if the member of the string is uppercase,
then it is converted to lowercase, by storing it in a character.
3) If the member of the string is in lowercase, then it is converted to upper case
by storing it in a character.
4) And if the character is not an alphabet, like spaces in the case of the test case,
then it is printed as it is.*/

void upper(char *string)
{
    int i,j;
    j=strlen(string);
    for(i=0;i<j;i++)
    {
        char a = toupper(string[i]);
        printf("%c",a);
    }
}
/*The above function-
1) Takes in a character pointer string
2) Using a for loop, converts all the elements of the string 
to uppercase*/

void lower(char *string)
{
    int i,j;
    j=strlen(string);
    for(i=0;i<j;i++)
    {
        char a = tolower(string[i]);
        printf("%c",a);
    }

}
/*The above function-
1) Takes in a character pointer string
2) And using a for loop, converts all the elements of the 
string to lowercase*/

void quit()
{
    exit(1);
}
/*The above function is used to quit the execution*/
void (*func_ptr[4])(char *string)={upper,lower,upperorlower,quit};
/*The above function pointer array is used to store all the functions
and use it instead of a switch case*/
int main()
{
    char str[100];
    fgets(str,sizeof(str),stdin);
    /*Reading a string*/
    while(1)
    {int input;
    scanf("%d",&input);
    (func_ptr[input-1])(str);
    }
    /*Using while loop to scan the integer and calling the 
    function pointer using the integer - 1, taking in the 
    consideration that the index of the arrays starts from 0*/

    return 0;
}

