/*
   CH-230-B
   a7_p2.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<stdlib.h>

struct Node  {
	char data;
	struct Node* next;
	struct Node* prev;
};
/*Declaring a doubly linked list*/

struct Node* head = NULL;

struct Node* NewNode(char x) {
	struct Node* NewNode= (struct Node*)malloc(sizeof(struct Node));
	if(NewNode == NULL)
    {
        exit(1);
    }
	NewNode->data = x;
	NewNode->prev = NULL;
	NewNode->next = NULL;
	return NewNode;
}
/*The above function is used to dynamically allocate and
create a new node which is to be inserted*/

void InsertAtHead(char x) {
	struct Node* newNode = NewNode(x);
	if(head == NULL) {
		head = newNode;
		return;
	}
	head->prev = newNode;
	newNode->next = head;
	head = newNode;
}
/*The above function-
1) Takes in a character
2) It checks if the list is empty, the the
character is initialized to the head
3) Otherwise the address of the newnode is stored
in the previous pointer of the head and the address
of head is stored in the next pointer of the newnode
hence attaching it in the start*/
void Print() {
	struct Node* temp = head;
	while(temp != NULL) {
		printf("%c ",temp->data);
		temp = temp->next;
	}
	printf("\n");
}
/*The above function is using a for loop and
a struct node type pointer temp to
print all the elements of the doubly linked list*/
void ReversePrint() {
	struct Node* temp = head;
	if(temp == NULL) return;
	while(temp->next != NULL) {
		temp = temp->next;
	}
	while(temp != NULL) {
		printf("%c ",temp->data);
		temp = temp->prev;
	}
	printf("\n");
}
/*The above function-
1)Makes a new struct node type pointer temp
and initializes it to head.
2)It reverses the elements of the linked list
by initializing the value of temp by equating
it to the value of the element whose address is
stored in the previous pointer of temp*/

void remove_data() {
   char data;
   scanf("%c",&data);
   /*Scanning the character to be removed*/
   struct Node *p;
   struct Node *current = NULL;
   /*Declaring struct node type pointers and initializing them to
   NULL*/

   while(p != NULL)
    /*Using for loop to remove all the same elements*/
   {if(head==NULL)
    {

    }
    /*If the list is empty, then do nothing*/

   if(head->data == data)
    {
      if(head->next != NULL)
      {
         head->next->prev = NULL;
         head = head->next;
      }
      /*Using if to check whether the element is in the
      start of the list and if yes then changing the address
      of head*/
      else
      {
         head = NULL;
      }
   }
   else if(head->data != data && head->next == NULL)
    {

    }

   current = head;
   /*If the first element is not to be removed*/

   while(current->next != NULL && current->data != data)
    {
      p = current;
      current = current->next;
    }
    /*Using while loop to initialize the current pointer to p
    until the value of current is not the same character which
    is to be removed*/

   if(current->data == data)
    {
      p->next = p->next->next;

      if(p->next != NULL)
        {
         p->next->prev = p;
        }
      else
         {
         }

      free(current);
   }
   else
   {
       printf("The element is not in the list!\n");
       break;
       /*If element is not in the list then printing
       the message*/
   }
   /*Using nested if loop to free the pointer p,
   which has the character which is to be removed*/
   p=p->next;

   }

}
void empty_list()
{
    struct Node* a;
    struct Node* b;
    a = head;
    while(a != NULL)
    {
        b = a->next;
        free(a);
        a = b;
     }

}
/*The above function is used to empty and free
the list*/


int main() {

	while(1)
    {
        int i;
        char c;
        scanf("%d",&i);
        /*Scanning the input for function call*/
        switch(i)
        {
        case 1:
            getchar();
            scanf("%c",&c);
            InsertAtHead(c);
            break;
        case 2:
            getchar();
            remove_data();
            break;
        case 3:
            Print();
            break;
        case 4:
            ReversePrint();
            break;
        case 5:

            exit(1);

        }
        /*Using switch case to call the functions according
        to the user input*/
    }

}
