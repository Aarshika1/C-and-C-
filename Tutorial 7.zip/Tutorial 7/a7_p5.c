#include<stdio.h>
#include<stdlib.h>
int compare1(const void *a, const void *b)
{
    const int *ia = (const int *)a;
    const int *ib = (const int *)b;
    if(*ia < *ib)
    return -1;
    else if(* ia> *ib)
    return 1;
    else
    return 0;
}
int compare2(const void *a, const void *b)
{
    const int *ia = (const int *)a;
    const int *ib = (const int *)b;
    if(*ia < *ib)
    return 1;
    else if(* ia> *ib)
    return -1;
    else
    return 0;
}

int main()
{
    int n,i;
    scanf("%d",&n);
    int array[n];
    for(i=0;i<n;i++)
    {
        scanf("%d",&array[i]);
    }
    char c;
    while(1)
    {
        scanf("%c",&c);
        if(c=='a')
        {
            qsort(array,n,sizeof(array[0]),compare1);
            for(i=0;i<n;i++)
            {
                printf("%d",array[i]);
            }
            printf("\n");

        }
        if(c=='d')
        {
             qsort(array,n,sizeof(array[0]),compare2);
            for(i=0;i<n;i++)
            {
                printf("%d",array[i]);
            }
            printf("\n");
        }
        if(c=='e')
        {
            exit(1);
        }
    }
return 0;
}