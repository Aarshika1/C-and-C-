/*
   CH-230-B
   a7_p1.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#ifndef LINKED_LIST_H_INCLUDED
#define LINKED_LIST_H_INCLUDED
typedef struct list
{
    int info;
    struct list *link;
}node;
void insertElel();
void insertEleb();
void deleteEle();
void print();
void freeEle();
#endif // LINKED_LIST_H_INCLUDED
