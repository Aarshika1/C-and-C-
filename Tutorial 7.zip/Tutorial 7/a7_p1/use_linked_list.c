/*
   CH-230-B
   a7_p1.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<stdlib.h>
/*Including libraries*/
#include "linked_list.h"

/*Declaring a pointer of type struct list, using node and
initializing to NULL*/
int main()
{

    while(1)
        /*(1) Using while to read until q is scanned*/
    {
        char c;
        scanf("%c",&c);
    /*(2) Reading character*/
        switch(c)
        {
        case 'a':
            insertElel();
            break;
        case 'b':
            insertEleb();
            break;
        case 'p':
            print();
            break;
        case 'r':
            deleteEle();
            break;
        case 'q':
            freeEle();
            exit(0);
        default:
            printf("Invalid choice\n");
        }
        /*(3) Using switch to call the particular function
        according to the character scanned*/
        getchar();
    }
return 0;
}
