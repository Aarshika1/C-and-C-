/*
   CH-230-B
   a7_p7.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

int main()
{
    st.count = -1;
    /*Intialising to -1*/
    while(1)
    {
        char c;
        int i;
        scanf("%c",&c);
        /*Scanning the character*/
        switch(c)
        {
            case 's':
            scanf("%d",&i);
            push(i);
            break;
            case 'p':
            i = pop();
            if(i==0)
            {
                printf("Popping Stack Underflow\n");
            }
            else
            {
                printf("Popping %d\n",i);
            }
            break;
            case 'e':
            empty();
            break;
            case 'q':
            printf("Quit\n");
            exit(0);
        }
        /*Using switch for different cases*/
    }
return 0;
}
