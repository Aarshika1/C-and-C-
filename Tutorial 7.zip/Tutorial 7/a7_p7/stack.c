/*
   CH-230-B
   a8_p4.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
int isFull()
{
    if(st.count == 11)
    {
        return 1;
    }
    else
    {
        return 0;
    }

}
/*The above function checks if the count is
equal to 11 then no more elements can be added,
because the size of the array is 12*/
void push(int i)
{
    if(isFull())
    {

    }
    else
    {
        st.count++;
        st.array[st.count]=i;
    }
}
/*The above function takes in an integer,
and if the stack is not full, then pushes
the integer by incrementing the count variable
in the structure*/

int isEmpty()
{
    if(st.count == -1)
    {
        return 1;
    }
    else
    {
        return 0;
    }

}
/*The above functions checks if the stack is
empty, by checking if the count is equal to
-1*/
int pop()
{
    if(isEmpty())
    {
        return 0;
    }
    else
    {
        return st.array[st.count--];
    }

}
/*The above function firsts checks for the
emptiness of the stack, and if it is not empty,
then prints the topmost elements and decrements
the count variable of the stack*/

void empty()
{
    printf("Emptying Stack ");
    while(st.count != -1)
    {
        printf("%d ",st.array[st.count--]);
    }
    printf("\n");
}
/*The above functions pops out all the integers in
the stack till it becomes empty*/
