/*
   CH-230-B
   a8_p4.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED
struct stack {
unsigned int count;
int array[12];
}st;
/*Declaring the structure*/
int isFull();
void push(int i);
int isEmpty();
int pop();
void empty();
#endif // STACK_H_INCLUDED
