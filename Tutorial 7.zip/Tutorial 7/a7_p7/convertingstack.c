/*
   CH-230-B
   a8_p4.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

int main()
{
unsigned int i;
/*Declaring an unsigned integer*/
st.count=-1;
scanf("%d",&i);
/*Reading the integer to be converted to binary*/
printf("The binary representation of %d is ",i);
if(i==0)
{
   printf("0");
}
else{
    while((i!=0))
    {
       if(!isFull())
          {
            push(i%2);
            i=i/2;
          }
          /*If the stack is not full then converting the 
          integer i to binary by dividing by 2 and storing
          the remainder in the stack*/
       else
          {
            printf("Stack overflow");
            exit(0);
          }
          /*But if the stack is full then printing the message*/
    }
    while(!isEmpty())
       {
        i=pop();
        printf("%d",i);
       }
        /*While stack is not empty, printing the binary digits 
        on the screen using pop and printf function*/
        printf(".");
        /*Printing full stop*/
        printf("\n");
}

return 0;
}
