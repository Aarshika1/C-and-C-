//CH-230-B
//a9_p4.c
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
//Including library
using namespace std;
int mycount(int a, int b)
{
    return (b-a);
}
//The above function takes in two integers
//and return the difference of the second
//and the first intger
int mycount(char c, string str)
{
    unsigned int i;
    int count = 0;
    for(i=0;i<str.length();i++)
    {
        if(str[i]==c)
        {
            count++;
        }

    }
    return count;
}
//The above function takes in a character and string
//and has a counter variable count. It checks the 
//occurance of the character in the string using
//if loop and increments the counter variable by 1
//whenver the character is found. It returns the 
//counter variable
int main()
{
    int a,b;
    //Declaring two integers
    cout << "Enter first integer: ";
    cin >> a;
    //Reading the first integer
    cout << "Enter second integer: ";
    cin >> b;
    //Reading the second integer
    char c;
    //Declaring a character*/
    string str;
    //Declaring a string
    cout << "Enter a character: ";
    cin >> c;
    //Reading the character
    //getchar();
    cout << "Enter a string: ";
    //cin.ignore();
    //Used with numbers so read string
    //getline(cin,str);
    cin>>str;
    //Reading the string
    cout << mycount(a,b) << endl;
    cout << mycount(c,str) << endl;
    //Calling the function and fucntion overloading is used
    return 0;
}