//CH-230-B
//a9_p7.c
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
//Including library
using namespace std;
int myfirst(int n,int arr[])
{
    int i;
    for(i=0;i<n;i++)
    {
        if(arr[i]>0)
        {
            if((arr[i]%2)==0)
            {
                return arr[i];
                break;
            }
            
        }
        
    }
    return -1;
}
//The above function takes in an integer as the size of the array,
//and an array of integers. By using for loop, it checks if the 
//element is positive and even, if it is true then it returns the value
//of the element, otherwise it returns -1

double myfirst(int n,double arr[])
{
    int i;
    for(i=0;i<n;i++)
    {
        if(arr[i]<0)
        {
            if(arr[i]==(int)arr[i])
            {
                return arr[i];
            }
        }
    }
    return -1.1;
}
//The above function takes in an integer as the size of the array, 
//and an array of doubles. By using for loop, it checks if the element 
//is negative and if the double is equal to its integer part, then return 
//the element otherwise it returns -1.1

char myfirst(int n, char arr[])
{
    int i;
    for(i=0;i<n;i++)
    {
        if((arr[i] != 'a') && (arr[i] != 'e') && (arr[i] != 'i')
        && (arr[i] != 'o') && (arr[i] != 'u') && (arr[i] != 'A') && (arr[i] != 'E') &&
        (arr[i] != 'I') && (arr[i] != 'O') && (arr[i] != 'U'))
        {
            return arr[i];
        }
    }
return '0';
}
//The above function takes in an integer as the size of the array 
//and an array of characters. By using for loop, it checks if the character is 
// not vowels and returns the element, otherwise it returns the character 0
int main()
{
    int sizei;
    cout << "Enter the size of the array of integers: ";
    cin >> sizei;
    //Reading the size of the array of integers 
    int a,array[sizei];
    for(a=0;a<sizei;a++)
    {
        cout <<"Enter the " << a+1 << " integer ";
        cin >> array[a];

    }
    //Reading the elements of the array of integers
    int sized;
    cout << "Enter the size of the array of doubles: ";
    cin >> sized;
    //Reading the size of the array od doubles
    int b;
    double arrayd[sized];
    for(b=0;b<sized;b++)
    {
        cout << "Enter the "<<b+1<<" double ";
        cin >> arrayd[b];

    }
    //Reading the elements of the array of doubles
    int sizec;
    cout << "Enter the size of the array of characters: ";
    cin >> sizec;
    //Reading the size of the array of characters
    int c;
    char arrayc[sizec];
    for(c=0;c<sizec;c++)
    {
        cout <<"Enter the "<<c+1<<" character ";
        cin >> arrayc[c];

    }
    //Reading the elements of the array of characters
    cout << "The first positive and even element is: " <<  myfirst(sizei,array) << endl;
    cout << "The first negative element without a fractional part is: " << myfirst(sized,arrayd) << endl;
    cout << "The first consonant is: " << myfirst(sizec,arrayc) << endl;
    //Calling the functions
    return 0;
}