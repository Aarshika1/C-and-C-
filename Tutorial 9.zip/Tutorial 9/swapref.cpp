//CH-230-B
//a9_p8.c
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
using namespace std;
void swapping(int &a, int &b) 
{
    int help = a;
    a = b;
    b = help;
} // swap ints
// The above function takes in two integers and using
// a integer help swaps it by real calling by reference
void swapping(float &a, float &b) 
{
    float help = a;
    a = b;
    b = help;
} // swap floats
// The above function takes in two floats and using
// a float help swaps it by real calling by reference
void swapping(const char *&a, const char *&b) 
{
    const char *help = a;
     a = b;
     b = help;
} // swap char pointers
// The above function takes in two character pointers and using
// a character pointer help swaps it by real calling by reference
int main(void) 
{
    int a = 7, b = 15;
    //Declaring two integers
    float x = 3.5, y = 9.2;
    //Declaring two floats
    const char *str1 = "One";
    const char *str2 = "Two";
    //Declaring two strings
    cout << "a=" << a << ", b=" << b << endl;
    cout << "x=" << x << ", y=" << y << endl;
    cout << "str1=" << str1 << ", str2=" << str2 << endl;
    //Printing before swapping
    swapping(a, b);
    swapping(x, y);
    swapping(str1, str2);
    //Calling the functions
    cout << "a=" << a << ", b=" << b << endl;
    cout << "x=" << x << ", y=" << y << endl;
    cout << "str1=" << str1 << ", str2=" << str2 << endl;
    //Printing after swapping
    return 0;
}
