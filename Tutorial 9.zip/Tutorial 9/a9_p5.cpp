//CH-230-B
//a9_p5.c
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<stdbool.h>
//Including libraries
using namespace std;
int main()
{
    string str,s;
    //DEcalring strings
    bool compare=true;
    //Decalring a bool and initialising to true
    while(compare)
    //While the bool is true
    {
        cout << "Enter a string: ";
        getline(cin,str);
        //Reading the string
        if(str=="quit")
        {
            compare = false;
            
        }
        //If the string enetered is quit, then the bool 
        //becomes false and hence the loop breaks.
        else
        {
            s= s + str;
        }
        //Else concatenating the string using another empty string s.

    }
    cout << s << endl;
    //Printing the concatenated string

return 0;

}