//CH-230-B
//a9_p3.c
//Aarshika Singh
//aa.singh@jacobs-university.de

#include<iostream>
//Including library
using namespace std;

float absolute(float d)
{
    if(d<0)
    {
        return -d;
    }
    else
    {
        return d;
    }
}
//The above function-
//1) Takes in a float and return a float
//2) If the float enetered is less than zero,
//then, the value of the negative of the float is returned.
//3) Otherwise, the value of the positive of the float is returned
int main()
{
    float x;
    //Declaring a float
    cout << "Enter a float: ";
    cin >> x;
    //Scanning a float
    cout << "The absolute value is: ";
    cout << absolute(x) << endl;
    //Calling the function absolute
    return 0;
}