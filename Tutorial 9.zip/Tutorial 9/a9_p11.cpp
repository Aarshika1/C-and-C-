//CH-230-B
//a9_p11.c
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<cstring>
#include<stdbool.h>
//Including libraries
using namespace std;
bool isPalindrome(string s)
{
    if(s.empty())
    {
        return false;
    }
    int length = 0;
    int length2 = s.length()-1;
    while(length<length2)
    {
        if(s[length]!=s[length2])
        {
            return false;
        }
        length++;
        length2--;

    }
    return true;
}
// The above function-
// 1) Takes in a string and returns a bool
// 2) It compares the string with the reverse of the string
// and if they are same, then it returns true.
// 3) Otherwise, it returns false.
int main()
{
    cout << "Hello, This is the game Palindrome luck.Let us see if the "<< 
    "word in your mind is palindrome." << endl;
    //Printing the welcome message
    while(1)
    {
        string s;
        cout << "Please enter a word: ";
        getline(cin,s);
        //Reading the word
        if(s=="exit")
        {
            exit(1);
        }
        //If the word is exit then the execution is stopped
        if(isPalindrome(s))
        {
            cout <<"The word is a palindrome !!!" << endl;
        }
        //If the value returned is true, then the message is printed
        //accordingly of the word being a palindrome
        else
        {
            cout << "Oops!! The word is not a palindrome. Try again or enter 'exit'"<<
            "to exit" << endl;
        }
        //Otherwise the word is not a palindrome
    }
    
    return 0;
}