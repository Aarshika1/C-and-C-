//CH-230-B
//a9_p10.c
//Aarshika Singh
//aa.singh@jacobs-university.de
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
//Including libraries
using namespace std;
int main()
{
    cout <<"Welcome to Word Guess. Let's play with words"<<endl;
    while(1)
    //While loop for repetitive execution
    {
        srand(time(0));
        //Seeding random word generator
        unsigned int i;
        string Words[17] = { "computer","television","keyboard", 
            "laptop", "mouse", "smartphone", "assignments",
            "artificial", "camera", "intelligence", "bachelors", "programming", 
            "studies","graphics", "logical", "memory", "remote" };
            //Making an array of words

        int r = rand() % 17;
        //Generating a random number from 0 to 16
        string random = Words[r];
        //Using the randomly generated number as the index of the
        //array and extracting the random word
        for(i = 0; i < random.length(); i++)
        {
            if(random[i] == 'a' || random[i] == 'e' || random[i] == 'i' ||
            random[i] == 'o' || random[i] == 'u')
            {
                random[i] = '_';
            }
        }
        //Replacing the vowels with underscore using for loop

        cout <<"Word: "<< random << endl;
        //Printing the random word with underscore
        int tries=0;
        string input;
        do
        {
            tries++;
            cout << "Guess: ";
            cin >> input;
            if(input=="quit")
            {
                cout << "Bye";
                exit(1);
            }
        }
        //Taking the input from the user and increasing the number of tries
        //and stopping execution if quit is entered
        while(input!=Words[r]);
        //Using do while loop
        cout<<"Congratulations! You guessed the word in "<< tries << " tries" << endl;
        //Printing the message if correct word is entered with the number of tries
        cout<<"Continue or Quit ?"<<endl;
        //Asking the user to continue or quit
        string input2;
        cin >> input2;
        //Taking the input
        if(input2 == "Continue" || input2 == "continue")
        {
            continue;
        }
        //If Continue or continue, then the program is continued
        else if(input2 == "Quit" || input2 == "quit")
        {
            cout << "Bye";
            exit(1);
        }
        //If the input is Quit or quit, then the execution is stopped
    }

    return 0;
}