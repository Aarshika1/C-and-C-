//CH-230-B
//a9_p1.c
//Aarshika Singh
//aa.singh@jacobs-university.de

#include<iostream>
#include<string>
//Including libraries

using namespace std;

int main()
{
    string s;
    //Declaring string

    cout << "Please enter your country of origin: ";
    getline(cin,s);
    //Scanning string
    cout << "The country of origin is " << s << endl;
    //Printing the string
    return 0;
    
}