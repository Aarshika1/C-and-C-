//CH-230-B
//a9_p6.c
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<cstdlib>
#include<ctime>
//Including libraries
using namespace std;
int main()
{
    cout << "Number guessing game" << endl;
    string Name;
    cout << "Please enter your name: ";
    getline(cin,Name);
    //Reading the name of the player
    int random;
    srand(time(0));
    //Seed random number generator
    random = rand()%100+1;
    //Generating random number
    int input,tries=0;
    while(random != input)
    //Till the imput is not equal to the random number
    {
        cout << "Enter a number between 1 and 100: ";
        cin >> input;
        //Taking the input from user
        tries++;
        if(random > input)
        {
            cout << "Too low!! Try again." << endl;
        }
        //If the input is less than the random number
        else if(random < input)
        {
            cout << "Too high!! Try again." << endl;
        }
        //If the input is greater than the random number

    }
    cout << "Congrats " << Name << "!! You guessed it right! You took " << tries << " tries."<< endl;
    //If the input is same as the random number then congatulating the player
    return 0;
}