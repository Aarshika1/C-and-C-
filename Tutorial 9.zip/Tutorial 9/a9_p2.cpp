//CH-230-B
//a9_p2.c
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
#include<string>
//Including libraries

using namespace std;

int main()
{
    int n;
    //Declaring an integer
    cout << "Enter an integer: ";
    cin >> n;
    //Reading an integer 
    
    double x;
    //Declaring a double
    cout << "Enter a double: ";
    cin >> x;
    //Reading a double

    string s;
    //Declaring a string
    cout << "Enter a string: ";
    cin.ignore();
    //Using to take in string after numbers
    getline(cin,s);
    //Scanning the string

    int i;
    for(i=0;i<n;i++)
    {
        cout << s << ":" << x << " " ;
    }
    //Printing the double and string using for loop,
    // n number of times
    cout << endl;
    //Printing new line at end
    return 0;

}