//CH-230-B
//a9_p9.c
//Aarshika Singh
//aa.singh@jacobs-university.de
#include<iostream>
//Including library
using namespace std;
void subtract_max(int *&a,int &n)
{
    int i,j;
    int max = a[0];
    for(i=0;i<n;i++)
    {
        if(a[i]>max)
        {
            max=a[i];
        }
    }
    for(j=0;j<n;j++)
    {
        a[j]=a[j]-max;
    }
}
// The above function
// 1) Takes in an integer pointer and an integer by call by reference
// 2) It firsts sets an integer max to the first element and compares 
// the other elements using for loop and if the other element is greater
// then assigns the value of max to that element 
// 3) It then uses a for loop to subtract the max from every element of the 
// array
void deallocate(int *&a)
{
    delete [] a;
    cout << "The memory has been deallocated";
}
//The above function takes in an integer pointer by calling by reference
//and deletes the allocated memeory and a message is printed
int main()
{
    int n;
    cout << "Enter the number of element: ";
    cin >> n;
    //Reading an integer
    int *a = new(nothrow) int[n];
    if(a==NULL)
    {
        cout <<"No memory can be allocated" <<endl;
    }
    //Allocating memory
    int i;
    for(i=0;i<n;i++)
    {
        cout << "Enter the " << i+1 <<" element of the array: ";
        cin >> a[i];
    }
    //Reading the elements of the array using for loop
    cout << "Before subtracting the maximum value: ";
    int j;
    for(j=0;j<n;j++)
    {
        cout << a[j] << " ";
    }
    //Printing the array before subtraction
    cout << endl;
    cout << "After subtracting the maximum: ";
    subtract_max(a,n);
    //Calling the function
    int k;
    for(k=0;k<n;k++)
    {
        cout << a[k] << " ";
    }
    //Printing the array after subtraction
    cout << endl;
    deallocate(a);
    //Calling the function
    return 0;
}