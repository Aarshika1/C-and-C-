/*
   CH-230-B
   a8_p11.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<stdlib.h>
/*Including libraries*/

int main()
{
	int n;
	scanf("%d", &n);
	getchar();
	char **fileread;
	char buffer[64];
	/*Declaring buffer*/
	fileread=(char**)malloc(sizeof(char*)*n);
	if(fileread==NULL)
	{
		printf("Allocation error\n");
		exit(1);
	}
	/*Dynamically allocating memory*/
	int j;
	printf("Enter the names of the files\n");
	for (j = 0; j < n; j++)
	{
		fileread[j]=(char*)malloc(sizeof(char)*100);
		if(fileread[j]==NULL)
		{
			printf("Allocation error\n");
			exit(1);
		}
		scanf("%s",fileread[j]);
	}
	/*Scanning the names of files*/
	FILE *fp;
	FILE *fp2;
	printf("Concatenating the content of %d files...\n", n);
	printf("The result is:\n");
	fp = fopen("output.txt", "w");
	if (fp == NULL)
	{
		printf("File not found!\n");
		exit(1);
	}
	/*Opening the output file in writing mode*/
	for(j = 0; j < n ; j++)
	{
		fp2 = fopen(fileread[j],"r");
		if(fp2 == NULL)
		{
			printf("File not found");
			exit(1);
		}
		/*Opening the input files in reading mode*/
		while (!feof(fp2))
		{
			int nr = fread(buffer, sizeof(char), 64, fp2);
			fwrite(buffer, sizeof(char), nr, fp);
		}
		/*Writing the content of the files concatenated in the output 
		file*/
		printf("\n");
		fprintf(fp2,"%s","\n");
		fclose(fp2);
		/*Closing the input files in loop*/
	}
		
	fclose(fp);
	/*Closing the output files*/
	printf("The result was written into output.txt\n");
	return 0;
}