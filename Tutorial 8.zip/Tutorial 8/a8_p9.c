/*
   CH-230-B
   a8_p9.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h>

int main() 
{ 
    FILE *fp; 
    /*Declaring a file pointer*/
    char c; 
    int count=0;
    char file[20];
    int i=1;
    /*Declaring the name of the file to be scanned
    from the keyboard*/
	scanf("%s",file);  
    /*Scanning the name of the file*/  
    fp=fopen(file,"r"); 
    /*Opening the file in read mode*/
    if(fp==NULL) 
     { 
         printf("File does not exist"); 
         exit(1);
     } 
     /*If file is empty or does not exits, the printing
     the corresponding message*/
    else 
        { 
            while(!feof(fp))
            {
                c = getc(fp);
                if(c==' ' || c=='\n' || c=='\t' || c ==',' || c=='?'
                || c=='!' || c=='.' || c=='\r')
                {
                    if(i)
                    {
                        count++;
                    }
                    i=0;
                }
                else
                {
                    i=1;
                }
                
            }
 
        }
        /*while the character does not reach the end of the file and
        the character is equal to word or newline, increasing the 
        count by 1*/
        printf("The file contains %d words",count);       
        /*Printing the number of words in the file*/  

    fclose(fp); 
    /*Closing the file*/
    return 0;
}