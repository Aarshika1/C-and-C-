/*
   CH-230-B
   a8_p7.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<stdlib.h>
int main()
{
    double d1,d2;
    /*Declaring the doubles to be read*/
    double sum,diff,product,quotient;
    /*Creating variables to store results*/
    FILE *fp1,*fp2,*fp3;
    char file1 [20];
    char file2 [20];
    /*Declaring the file names*/
    printf("Enter the name of the first file: ");
    scanf("%s",file1);
    /*Scanning the name of the first input file from the user*/
    printf("Enter the name of the second file: ");
    scanf("%s",file2);
    /*Scanning the name of the second input file*/
    fp1 = fopen(file1,"r");
    fp2 = fopen(file2,"r");
    /*Opening the files in the read mode*/
    fp3 = fopen("results.txt","w");
    /*Opening the output file in the write mode*/
    if(fp1 == NULL)
    {
        printf("The file is empty");
        exit(1);
    }
    if(fp2 == NULL)
    {
        printf("The file is empty");
        exit(1);
    }
    /*If the input file is empty then printing the corresponding 
    results*/
    fscanf(fp1,"%lf",&d1);
    fscanf(fp2,"%lf",&d2);
    /*Reading the doubles from the input files*/
    sum = d1+d2;
    diff = d1-d2;
    product = d1*d2;
    quotient = d1/d2;
    /*Computing the operations*/

    fprintf(fp3,"Sum = %lf\n",sum);
    fprintf(fp3,"Difference = %lf\n",diff);
    fprintf(fp3, "Product = %lf\n",product);
    fprintf(fp3,"Division = %lf\n",quotient);
    /*Printing the results in the output file*/
    printf("The results have been stored in results.txt");
    fclose(fp1);
    fclose(fp2);
    fclose(fp3);
    /*Closing the files*/

    return 0;
}