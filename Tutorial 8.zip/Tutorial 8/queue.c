/*
   CH-230-B
   a8_p3.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
/**
 * @file queue.c
 */

#include <stdio.h>
#include <stdlib.h>

#include "queue.h"

void initialize_queue(Queue *pq)
{
	pq->front = pq->rear = NULL;
	pq->items = 0;
}

int queue_is_full(const Queue *pq)
{
	return pq->items == MAXQUEUE;
}

int queue_is_empty(const Queue *pq)
{
	return pq->items == 0;
}

int queue_item_count(const Queue *pq)
{
	return pq->items;
}

int enqueue(Item item, Queue *pq)
{
    if(queue_is_full(pq))
    {
        return -1;
    }
    else
    {
        Node *p = (Node*)malloc(sizeof(Node));
        p->item = item;
        p->next = NULL;
        if(pq->front == NULL && pq->rear == NULL)
        {
            pq->front = pq->rear = p;
        }
        else
        {
             pq->rear->next = p;
        }
        
        pq->rear = p;
        pq->items++;
    }
    
        return 0;
}
/*The above function-
1) First checks if the queue is empty using queue_is_full function
   and returns -1.
2) Makes a new Node using dynamic allocation of memory.
3) Copies the value to the node.
4) And points the next pointer to NULL.
5) Sets the front to NULL and rear node to the new node, if the 
   queue was empty.
6) Othwerwise, sets the rear pointer to the new node.
7) Increments the item variable by one and returns it.
*/

int dequeue(Item *pitem, Queue *pq)
{
	Node* n=(Node*)malloc(sizeof(Node));
    if (queue_is_empty(pq))
    {
		return -1;
	}
	*pitem=pq->front->item;
    n = pq->front;
	pq->front=pq->front->next;
	free(n);
    pq->items--;
    if(pq->items == 0){
		pq->front=NULL;
		pq->rear=NULL;
	}
    
    return 0;
}
/*The above function-
1) Makes a new node n.
2) Check if the queue is empty, then does nothing.
3) Copies the value to the waiting variable.
4) Sets the waiting variable to the front of the
queue.
5) Frees the value.
6) If the value removed is the last value, then 
the rear and the front pointers are set to NULL.
*/

void empty_queue(Queue *pq)
{
	Item dummy;
	while (!queue_is_empty(pq)) {
		dequeue(&dummy, pq);
	}
}


void printq(Queue *pq)
{ 
    Node *temp = pq->front;
    printf("content of the queue: ");
	while(temp != NULL) 
    {
		printf("%d ",temp->item);
		temp = temp->next;
	}
	printf("\n");
} 