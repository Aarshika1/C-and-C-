/*
   CH-230-B
   a8_p5.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stack.h"
int main()
{
    char string[100];
    Word Word;
    Word.item=0;
    Word.Word=NULL;
    /*Declaring the variables*/

    while(1)
    {
        fgets(string, 100, stdin);
        string[strlen(string)-1]='\0';
        /*Reading the string using fgets and removing the 
        \0 from the length of the string*/

    if(strcmp(string, "exit")==0)
    {
        break;
    }
    /*If the string entered is exit, then the program is 
    stopped*/
    else
    {   new(&Word, string);
        isPalindrome(&Word, string);
    }
    /*Otherwise, the function for creating a new stack and 
    checking whether the string is palindrome or not is called*/
}
 return 0;
}