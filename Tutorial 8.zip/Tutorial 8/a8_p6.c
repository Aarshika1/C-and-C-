/*
   CH-230-B
   a8_p6.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include<stdio.h>
#include<stdlib.h>
/*Including libraries*/
int main()
{
    char c1,c2;
    FILE *fp1,*fp2;
    fp1 = fopen("chars.txt","r");
    /*Opening file to read the imput*/
    fp2 = fopen("codesums.txt","w");
    /*Writing a file for output*/
    if(fp1 == NULL)
    {
        printf("The file is empty");
        exit(1);
    }
    /*If the input file is empty then printing
    the corresponding message*/
    c1 = fgetc(fp1);
    c2 = fgetc(fp1);
    /*Reading characters from the input file*/
    int i = c1+c2;
    /*Adding the characters, hence there ASCII code*/
    fprintf(fp2,"%d",i);
    /*Printing the sum in the output file*/

    fclose(fp1);
    fclose(fp2);
    /*Closing the files*/
    return 0;



}