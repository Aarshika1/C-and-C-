/*
   CH-230-B
   a8_p8.c
   Aarshika Singh
   aa.singh@jacobs-university.de
*/
#include <stdio.h> 
#include <stdlib.h> 
  
int main() 
{ 
   FILE *fp1 = fopen("text1.txt","r"); 
   FILE *fp2 = fopen("text2.txt","r"); 
   /*Two input files which are to be read*/
   FILE *fp3 = fopen("merge12.txt","w"); 
   /*The output file which will be written*/
   if (fp1 == NULL || fp2 == NULL || fp3 == NULL) 
   { 
         puts("Files cannot be opened"); 
         exit(0); 
   } 
   /*Checking if the files are empty*/ 
   char line1[128];
   char line2[128];
   while (fgets(line1,128,fp1)!=NULL) 
   {
       fputs(line1, fp3);
   }
   /*Putting the characters of text1 to merge12*/
   fprintf(fp3,"\n");
   /*Printing newline character in merge12*/
   while (fgets(line2,128,fp2)!=NULL) 
   {
       fputs(line2, fp3);
   }
   /*Putting the characters of the text2 to merge12*/
   fclose(fp1); 
   fclose(fp2); 
   fclose(fp3); 
   /*Closing all the files*/
   return 0; 
} 